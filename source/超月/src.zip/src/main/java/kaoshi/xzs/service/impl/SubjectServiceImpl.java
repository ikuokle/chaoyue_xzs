package xzs.service.impl;

//实现了   SubjectService   接口的服务类，专门处理与学科相关的业务逻辑。
// 它的主要功能包括：
// 1. 通用数据库操作：继承自   BaseServiceImpl   的增删改查方法。
// 2. 按级别查询学科：根据学科级别查询学科列表。
// 3. 查询所有学科：获取所有学科的列表。
// 4. 分页查询：提供分页查询功能。
// 5. 根据学科 ID 获取年级级别：根据学科 ID 查询对应的年级级别。

import xzs.domain.Subject;
import xzs.repository.SubjectMapper;
import xzs.service.SubjectService;
import xzs.viewmodel.admin.education.SubjectPageRequestVM;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class SubjectServiceImpl extends BaseServiceImpl<Subject> implements SubjectService {

    private final SubjectMapper subjectMapper;

    @Autowired
    public SubjectServiceImpl(SubjectMapper subjectMapper) {
        super(subjectMapper);
        this.subjectMapper = subjectMapper;
    }

    @Override
    public Subject selectById(Integer id) {
        return super.selectById(id);
    }

    @Override
    public int updateByIdFilter(Subject record) {
        return super.updateByIdFilter(record);
    }

    @Override
    public List<Subject> getSubjectByLevel(Integer level) {
        return subjectMapper.getSubjectByLevel(level);
    }

    @Override
    public List<Subject> allSubject() {
        return subjectMapper.allSubject();
    }

    @Override
    public Integer levelBySubjectId(Integer id) {
        return this.selectById(id).getLevel();
    }

    @Override
    public PageInfo<Subject> page(SubjectPageRequestVM requestVM) {
        return PageHelper.startPage(requestVM.getPageIndex(), requestVM.getPageSize(), "id desc").doSelectPageInfo(() ->
                subjectMapper.page(requestVM)
        );
    }

}

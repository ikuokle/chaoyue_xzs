package xzs.configuration.spring.security;


import xzs.context.WebContext;
import xzs.domain.enums.RoleEnum;
import xzs.domain.enums.UserStatusEnum;
import xzs.service.AuthenticationService;
import xzs.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.LockedException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Component;

import java.util.ArrayList;

//验证用户身份
@Component
public class RestAuthenticationProvider implements AuthenticationProvider {

    private final AuthenticationService authenticationService;
    private final UserService userService;

    @Autowired
    public RestAuthenticationProvider(AuthenticationService authenticationService, UserService userService, WebContext webContext) {
        this.authenticationService = authenticationService;
        this.userService = userService;
    }//通过与后端服务层（用户服务   UserService   和认证服务   AuthenticationService  ）交互来验证用户身份

    @Override
    public Authentication authenticate(Authentication authentication) throws AuthenticationException {
        String username = authentication.getName();
        String password = (String) authentication.getCredentials();

        xzs.domain.User user = userService.getUserByUserName(username);
        if (user == null) {
            throw new UsernameNotFoundException("用户名或密码错误");
        }

        boolean result = authenticationService.authUser(user, username, password);
        if (!result) {
            throw new BadCredentialsException("用户名或密码错误");
        }

        UserStatusEnum userStatusEnum = UserStatusEnum.fromCode(user.getStatus());
        if (UserStatusEnum.Disable == userStatusEnum) {
            throw new LockedException("用户被禁用");
        }

        ArrayList<GrantedAuthority> grantedAuthorities = new ArrayList<>();
        grantedAuthorities.add(new SimpleGrantedAuthority(RoleEnum.fromCode(user.getRole()).getRoleName()));

        User authUser = new User(user.getUserName(), user.getPassword(), grantedAuthorities);
        return new UsernamePasswordAuthenticationToken(authUser, authUser.getPassword(), authUser.getAuthorities());
    }
/*1. 获取用户名和密码：从传入的   Authentication   对象中提取用户名和密码。
2. 查询用户信息：调用   UserService   通过用户名查询用户信息。
3. 检查用户是否存在：如果用户不存在，抛出   UsernameNotFoundException  。
4. 验证用户凭据：调用   AuthenticationService   来验证用户名和密码是否正确。
5. 检查用户状态：验证用户状态是否有效（例如，是否被禁用）。
6. 设置权限：根据用户角色设置相应的权限（  GrantedAuthority  ）。
7. 创建认证令牌：创建并返回一个   UsernamePasswordAuthenticationToken   对象，包含认证信息和权限信息。*/
    @Override
    public boolean supports(Class<?> aClass) {
        return true;
    }//意味着它声明自己可以处理任何类型的   Authentication   对象
}

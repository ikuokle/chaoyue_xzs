package xzs.repository;

//扩展了针对   ExamPaper   实体的特定数据库操作方法。
// 它的主要功能包括：
// 通用数据库操作：继承自   BaseMapper   的增删改查方法。
// 分页查询：提供不同场景下的分页查询功能，包括管理员端、任务相关和学生端的分页查询。
// 统计查询：按日期范围统计试卷的数量。
// 特定记录查询：根据特定条件查询试卷信息。
// 批量更新：支持批量更新试卷的关联任务信息

import xzs.domain.ExamPaper;
import xzs.domain.other.KeyValue;
import xzs.viewmodel.admin.exam.ExamPaperPageRequestVM;
import xzs.viewmodel.student.dashboard.PaperFilter;
import xzs.viewmodel.student.dashboard.PaperInfo;
import xzs.viewmodel.student.exam.ExamPaperPageVM;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.Date;
import java.util.List;

@Mapper
public interface ExamPaperMapper extends BaseMapper<ExamPaper> {

    List<ExamPaper> page(ExamPaperPageRequestVM requestVM);

    List<ExamPaper> taskExamPage(ExamPaperPageRequestVM requestVM);

    List<ExamPaper> studentPage(ExamPaperPageVM requestVM);

    List<PaperInfo> indexPaper(PaperFilter paperFilter);

    Integer selectAllCount();

    List<KeyValue> selectCountByDate(@Param("startTime") Date startTime, @Param("endTime") Date endTime);

    int updateTaskPaper(@Param("taskId") Integer taskId,@Param("paperIds") List<Integer> paperIds);

    int clearTaskPaper(@Param("paperIds") List<Integer> paperIds);
}

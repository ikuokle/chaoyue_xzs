package xzs.configuration.spring.security;

import xzs.base.SystemCode;
import xzs.domain.UserEventLog;
import xzs.event.UserEvent;
import xzs.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.web.authentication.SimpleUrlAuthenticationSuccessHandler;
import org.springframework.stereotype.Component;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.Date;

//处理用户成功认证后的逻辑
@Component
public class RestAuthenticationSuccessHandler extends SimpleUrlAuthenticationSuccessHandler {

    private final ApplicationEventPublisher eventPublisher;
    private final UserService userService;

    @Autowired
    public RestAuthenticationSuccessHandler(ApplicationEventPublisher eventPublisher, UserService userService) {
        this.eventPublisher = eventPublisher;
        this.userService = userService;
    }

    @Override
    public void onAuthenticationSuccess(HttpServletRequest request, HttpServletResponse response,
                                        Authentication authentication) throws IOException, ServletException {
        Object object = authentication.getPrincipal();
        if (null != object) {
            User springUser = (User) object;
            xzs.domain.User user = userService.getUserByUserName(springUser.getUsername());
            if (null != user) {
                UserEventLog userEventLog = new UserEventLog(user.getId(), user.getUserName(), user.getRealName(), new Date());
                userEventLog.setContent(user.getUserName() + " 登录了超月小助手考试系统");
                eventPublisher.publishEvent(new UserEvent(userEventLog));
                xzs.domain.User newUser = new xzs.domain.User();
                newUser.setUserName(user.getUserName());
                newUser.setImagePath(user.getImagePath());
                RestUtil.response(response, SystemCode.OK.getCode(), SystemCode.OK.getMessage(), newUser);
            }
        } else {
            RestUtil.response(response, SystemCode.UNAUTHORIZED.getCode(), SystemCode.UNAUTHORIZED.getMessage());
        }
    }//这个方法在用户成功认证后被调用
    /*1. 获取认证信息：从   Authentication   对象中获取用户信息。
    2. 查询用户详情：使用   UserService   通过用户名查询用户详细信息。
    3. 记录用户事件：创建一个   UserEventLog   对象，记录用户的登录事件，并通过   ApplicationEventPublisher   发布这个事件。
    4. 构建响应：如果用户存在，构建一个包含用户信息的响应，并使用   RestUtil.response   方法发送给客户端。
    5. 处理用户不存在的情况：如果用户不存在，发送一个未授权的错误响应。*/
}

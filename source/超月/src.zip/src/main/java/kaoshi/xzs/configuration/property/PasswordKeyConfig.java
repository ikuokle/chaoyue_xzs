package xzs.configuration.property;

//存储和管理系统中使用的公钥和私钥
public class PasswordKeyConfig {
    private String publicKey;//存储公钥

    private String privateKey;//存储私钥

    public String getPublicKey() {
        return publicKey;
    }
    //返回公钥
    public void setPublicKey(String publicKey) {
        this.publicKey = publicKey;
    }
    //设置公钥
    public String getPrivateKey() {
        return privateKey;
    }
    //存储私钥
    public void setPrivateKey(String privateKey) {
        this.privateKey = privateKey;
    }
    //设置私钥
}

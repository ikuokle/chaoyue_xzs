package xzs.controller.admin;

import xzs.base.BaseApiController;
import xzs.base.RestResponse;
import xzs.base.SystemCode;
import xzs.domain.Question;
import xzs.domain.TextContent;
import xzs.domain.enums.QuestionTypeEnum;
import xzs.domain.question.QuestionObject;
import xzs.service.QuestionService;
import xzs.service.TextContentService;
import xzs.utility.*;
import xzs.utility.*;
import xzs.viewmodel.admin.question.QuestionEditRequestVM;
import xzs.viewmodel.admin.question.QuestionPageRequestVM;
import xzs.viewmodel.admin.question.QuestionResponseVM;
import com.github.pagehelper.PageInfo;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

//Spring MVC控制器，专门用于处理与问题（Question）相关的管理操作。
// 这个控制器扩展自   BaseApiController  ，
// 提供了管理问题列表、编辑问题、选择特定问题以及删除问题的RESTful API端点。
// 它通过依赖注入   QuestionService 和 TextContentService  来访问问题和文本内容相关的业务逻辑

@RestController("AdminQuestionController")
@RequestMapping(value = "/api/admin/question")
public class QuestionController extends BaseApiController {

    private final QuestionService questionService;//用于操作问题的服务
    private final TextContentService textContentService;//用于操作文本内容的服务

    @Autowired
    public QuestionController(QuestionService questionService, TextContentService textContentService) {
        this.questionService = questionService;
        this.textContentService = textContentService;
    }

    @RequestMapping(value = "/page", method = RequestMethod.POST)
    public RestResponse<PageInfo<QuestionResponseVM>> pageList(@RequestBody QuestionPageRequestVM model) {
        PageInfo<Question> pageInfo = questionService.page(model);
        PageInfo<QuestionResponseVM> page = PageInfoHelper.copyMap(pageInfo, q -> {
            QuestionResponseVM vm = modelMapper.map(q, QuestionResponseVM.class);
            vm.setCreateTime(DateTimeUtil.dateFormat(q.getCreateTime()));
            vm.setScore(ExamUtil.scoreToVM(q.getScore()));
            TextContent textContent = textContentService.selectById(q.getInfoTextContentId());
            QuestionObject questionObject = JsonUtil.toJsonObject(textContent.getContent(), QuestionObject.class);
            String clearHtml = HtmlUtil.clear(questionObject.getTitleContent());
            vm.setShortTitle(clearHtml);
            return vm;
        });
        return RestResponse.ok(page);
    }//处理分页查询问题的请求

    @RequestMapping(value = "/edit", method = RequestMethod.POST)
    public RestResponse edit(@RequestBody @Valid QuestionEditRequestVM model) {
        RestResponse validQuestionEditRequestResult = validQuestionEditRequestVM(model);
        if (validQuestionEditRequestResult.getCode() != SystemCode.OK.getCode()) {
            return validQuestionEditRequestResult;
        }

        if (null == model.getId()) {
            questionService.insertFullQuestion(model, getCurrentUser().getId());
        } else {
            questionService.updateFullQuestion(model);
        }

        return RestResponse.ok();
    }//处理编辑问题的请求

    @RequestMapping(value = "/select/{id}", method = RequestMethod.POST)
    public RestResponse<QuestionEditRequestVM> select(@PathVariable Integer id) {
        QuestionEditRequestVM newVM = questionService.getQuestionEditRequestVM(id);
        return RestResponse.ok(newVM);
    }//根据给定ID选择特定问题的请求


    @RequestMapping(value = "/delete/{id}", method = RequestMethod.POST)
    public RestResponse delete(@PathVariable Integer id) {
        Question question = questionService.selectById(id);
        question.setDeleted(true);
        questionService.updateByIdFilter(question);
        return RestResponse.ok();
    }//根据给定ID删除问题的请求

    private RestResponse validQuestionEditRequestVM(QuestionEditRequestVM model) {
        int qType = model.getQuestionType().intValue();
        boolean requireCorrect = qType == QuestionTypeEnum.SingleChoice.getCode() || qType == QuestionTypeEnum.TrueFalse.getCode();
        if (requireCorrect) {
            if (StringUtils.isBlank(model.getCorrect())) {
                String errorMsg = ErrorUtil.parameterErrorFormat("correct", "不能为空");
                return new RestResponse<>(SystemCode.ParameterValidError.getCode(), errorMsg);
            }
        }
//验证必填字段：检查问题编辑视图模型中的某些字段是否为空，比如对于单选题（SingleChoice）或判断题（TrueFalse）来说，正确答案（  correct  ）是必填的

        if (qType == QuestionTypeEnum.GapFilling.getCode()) {
            Integer fillSumScore = model.getItems().stream().mapToInt(d -> ExamUtil.scoreFromVM(d.getScore())).sum();
            Integer questionScore = ExamUtil.scoreFromVM(model.getScore());
            if (!fillSumScore.equals(questionScore)) {
                String errorMsg = ErrorUtil.parameterErrorFormat("score", "空分数和与题目总分不相等");
                return new RestResponse<>(SystemCode.ParameterValidError.getCode(), errorMsg);
            }
        }
//验证分数逻辑：对于填空题（GapFilling），需要验证所有题目项的分数总和是否与题目总分相等。如果不等，返回错误信息
        return RestResponse.ok();
//返回验证结果：如果验证通过，则返回一个表示成功的   RestResponse   对象；
// 如果不通过，则返回一个包含错误码和错误信息的   RestResponse   对象
    }
}

package xzs.controller.student;

import xzs.base.BaseApiController;
import xzs.base.RestResponse;
import xzs.domain.Message;
import xzs.domain.MessageUser;
import xzs.domain.User;
import xzs.domain.UserEventLog;
import xzs.domain.enums.RoleEnum;
import xzs.domain.enums.UserStatusEnum;
import xzs.event.UserEvent;
import xzs.service.AuthenticationService;
import xzs.service.MessageService;
import xzs.service.UserEventLogService;
import xzs.service.UserService;
import xzs.utility.DateTimeUtil;
import xzs.utility.PageInfoHelper;
import xzs.viewmodel.student.user.*;
import com.github.pagehelper.PageInfo;
import xzs.viewmodel.student.user.*;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.Date;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

//Spring MVC控制器，专门为学生用户设计，用于处理与用户账户相关的请求。
// 这个控制器扩展自   BaseApiController  ，
// 提供了管理用户信息、注册新用户、更新用户资料、查看用户事件日志、查看消息以及读取消息状态的端点

@RestController("StudentUserController")
@RequestMapping(value = "/api/student/user")
public class UserController extends BaseApiController {

    private final UserService userService;//用于操作用户信息的服务
    private final UserEventLogService userEventLogService;//用于操作用户事件日志的服务
    private final MessageService messageService;//用于操作消息的服务
    private final AuthenticationService authenticationService;//用于处理认证的服务
    private final ApplicationEventPublisher eventPublisher;//用于发布应用事件

    @Autowired
    public UserController(UserService userService, UserEventLogService userEventLogService, MessageService messageService, AuthenticationService authenticationService, ApplicationEventPublisher eventPublisher) {
        this.userService = userService;
        this.userEventLogService = userEventLogService;
        this.messageService = messageService;
        this.authenticationService = authenticationService;
        this.eventPublisher = eventPublisher;
    }

    @RequestMapping(value = "/current", method = RequestMethod.POST)
    public RestResponse<UserResponseVM> current() {
        User user = getCurrentUser();
        UserResponseVM userVm = UserResponseVM.from(user);
        return RestResponse.ok(userVm);
    }//获取当前登录用户的信息


    @RequestMapping(value = "/register", method = RequestMethod.POST)
    public RestResponse register(@RequestBody @Valid UserRegisterVM model) {
        User existUser = userService.getUserByUserName(model.getUserName());
        if (null != existUser) {
            return new RestResponse<>(2, "用户已存在");
        }
        User user = modelMapper.map(model, User.class);
        String encodePwd = authenticationService.pwdEncode(model.getPassword());
        user.setUserUuid(UUID.randomUUID().toString());
        user.setPassword(encodePwd);
        user.setRole(RoleEnum.STUDENT.getCode());
        user.setStatus(UserStatusEnum.Enable.getCode());
        user.setLastActiveTime(new Date());
        user.setCreateTime(new Date());
        user.setDeleted(false);
        userService.insertByFilter(user);
        UserEventLog userEventLog = new UserEventLog(user.getId(), user.getUserName(), user.getRealName(), new Date());
        userEventLog.setContent("欢迎 " + user.getUserName() + " 注册来到超月小助手考试系统");
        eventPublisher.publishEvent(new UserEvent(userEventLog));
        return RestResponse.ok();
    }//注册新用户


    @RequestMapping(value = "/update", method = RequestMethod.POST)
    public RestResponse update(@RequestBody @Valid UserUpdateVM model) {
        if (StringUtils.isBlank(model.getBirthDay())) {
            model.setBirthDay(null);
        }
        User user = userService.selectById(getCurrentUser().getId());
        modelMapper.map(model, user);
        user.setModifyTime(new Date());
        userService.updateByIdFilter(user);
        UserEventLog userEventLog = new UserEventLog(user.getId(), user.getUserName(), user.getRealName(), new Date());
        userEventLog.setContent(user.getUserName() + " 更新了个人资料");
        eventPublisher.publishEvent(new UserEvent(userEventLog));
        return RestResponse.ok();
    }//更新当前登录用户的信息

    @RequestMapping(value = "/log", method = RequestMethod.POST)
    public RestResponse<List<UserEventLogVM>> log() {
        User user = getCurrentUser();
        //获取当前登录的用户对象

        List<UserEventLog> userEventLogs = userEventLogService.getUserEventLogByUserId
                (user.getId());
        //根据当前用户的 ID 查询其所有的用户事件日志

        List<UserEventLogVM> userEventLogVMS = userEventLogs.stream().map(d ->
                //将用户事件日志列表转换为用户事件日志视图模型列表
        {
            UserEventLogVM vm = modelMapper.map(d, UserEventLogVM.class);
            //将   UserEventLog   对象映射为   UserEventLogVM   对象

            vm.setCreateTime(DateTimeUtil.dateFormat(d.getCreateTime()));
            //将用户事件日志的创建时间格式化为字符串

            return vm;
        }).collect(Collectors.toList());
        return RestResponse.ok(userEventLogVMS);
    }//获取当前登录用户的事件日志

    @RequestMapping(value = "/message/page", method = RequestMethod.POST)
    public RestResponse<PageInfo<MessageResponseVM>> messagePageList(@RequestBody MessageRequestVM messageRequestVM) {
        messageRequestVM.setReceiveUserId(getCurrentUser().getId());
        PageInfo<MessageUser> messageUserPageInfo = messageService.studentPage(messageRequestVM);
        List<Integer> ids = messageUserPageInfo.getList().stream().map(d -> d.getMessageId()).collect(Collectors.toList());
        List<Message> messages = ids.size() != 0 ? messageService.selectMessageByIds(ids) : null;
        PageInfo<MessageResponseVM> page = PageInfoHelper.copyMap(messageUserPageInfo, e -> {
            MessageResponseVM vm = modelMapper.map(e, MessageResponseVM.class);
            messages.stream().filter(d -> e.getMessageId().equals(d.getId())).findFirst().ifPresent(message -> {
                vm.setTitle(message.getTitle());
                vm.setContent(message.getContent());
                vm.setSendUserName(message.getSendUserName());
            });
            vm.setCreateTime(DateTimeUtil.dateFormat(e.getCreateTime()));
            return vm;
        });
        return RestResponse.ok(page);
    }//获取消息列表

    @RequestMapping(value = "/message/unreadCount", method = RequestMethod.POST)
    public RestResponse unReadCount() {
        Integer count = messageService.unReadCount(getCurrentUser().getId());
        return RestResponse.ok(count);
    }//获取未读消息的数量

    @RequestMapping(value = "/message/read/{id}", method = RequestMethod.POST)
    public RestResponse read(@PathVariable Integer id) {
        messageService.read(id);
        return RestResponse.ok();
    }//标记消息为已读

}

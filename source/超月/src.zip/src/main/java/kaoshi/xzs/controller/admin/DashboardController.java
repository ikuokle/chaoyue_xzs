package xzs.controller.admin;

import xzs.base.BaseApiController;
import xzs.base.RestResponse;
import xzs.service.*;
import xzs.utility.DateTimeUtil;
import xzs.viewmodel.admin.dashboard.IndexVM;
import xzs.service.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

//Spring MVC控制器，它展示了如何使用Spring框架构建RESTful API

@RestController("AdminDashboardController")//标识该类是一个控制器，其所有方法的返回值都将自动转换为 JSON 格式的 HTTP 响应体。
@RequestMapping(value = "/api/admin/dashboard")//定义了类级别的请求映射，所有该控制器的方法都将在   /api/admin/dashboard   路径下。
public class DashboardController extends BaseApiController {

    private final ExamPaperService examPaperService;//用于操作考试试卷的服务
    private final QuestionService questionService;//用于操作问题的的服务
    private final ExamPaperAnswerService examPaperAnswerService;//用于操作考试答案的服务
    private final ExamPaperQuestionCustomerAnswerService examPaperQuestionCustomerAnswerService;
    //用于操作考试问题客户答案的服务
    private final UserEventLogService userEventLogService;
    //用于操作用户事件日志的服务

    @Autowired
    public DashboardController(ExamPaperService examPaperService, QuestionService questionService, ExamPaperAnswerService examPaperAnswerService, ExamPaperQuestionCustomerAnswerService examPaperQuestionCustomerAnswerService, UserEventLogService userEventLogService) {
        this.examPaperService = examPaperService;
        this.questionService = questionService;
        this.examPaperAnswerService = examPaperAnswerService;
        this.examPaperQuestionCustomerAnswerService = examPaperQuestionCustomerAnswerService;
        this.userEventLogService = userEventLogService;
    }

    @RequestMapping(value = "/index", method = RequestMethod.POST)
    public RestResponse<IndexVM> Index() {
        IndexVM vm = new IndexVM();

        Integer examPaperCount = examPaperService.selectAllCount();
        Integer questionCount = questionService.selectAllCount();
        Integer doExamPaperCount = examPaperAnswerService.selectAllCount();
        Integer doQuestionCount = examPaperQuestionCustomerAnswerService.selectAllCount();

        vm.setExamPaperCount(examPaperCount);
        vm.setQuestionCount(questionCount);
        vm.setDoExamPaperCount(doExamPaperCount);
        vm.setDoQuestionCount(doQuestionCount);

        List<Integer> mothDayUserActionValue = userEventLogService.selectMothCount();
        List<Integer> mothDayDoExamQuestionValue =
                examPaperQuestionCustomerAnswerService.selectMothCount();
        vm.setMothDayUserActionValue(mothDayUserActionValue);
        vm.setMothDayDoExamQuestionValue(mothDayDoExamQuestionValue);

        vm.setMothDayText(DateTimeUtil.MothDay());
        return RestResponse.ok(vm);
    }/*构建并返回一个   IndexVM  （视图模型），包含以下信息：
    • 考试试卷数量 (  examPaperCount  )
    • 问题数量 (  questionCount  )
    • 完成的考试试卷数量 (  doExamPaperCount  )
    • 完成的问题数量 (  doQuestionCount  )
    • 按月统计的用户行为数据 (  mothDayUserActionValue  )
    • 按月统计的完成考试问题数据 (  mothDayDoExamQuestionValue  )
    • 当前的月份和天数 (  mothDayText  )*/
}

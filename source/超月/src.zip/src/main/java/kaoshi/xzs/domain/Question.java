package xzs.domain;

//一个题目的详细信息

import xzs.domain.enums.QuestionTypeEnum;
import xzs.utility.ExamUtil;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

public class Question implements Serializable {
    private Integer id;

    private Integer questionType;// 题目类型

    private Integer subjectId;// 学科ID

    private Integer score; // 题目总分

    private Integer gradeLevel;// 级别

    private Integer difficult; // 题目难度

    private String correct;// 正确答案

    private Integer infoTextContentId; // 题目内容ID

    private Integer createUser;//创建人

    private Integer status;// 状态

    private Date createTime;// 状态

    private Boolean deleted;// 是否删除

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getQuestionType() {
        return questionType;
    }

    public void setQuestionType(Integer questionType) {
        this.questionType = questionType;
    }

    public Integer getSubjectId() {
        return subjectId;
    }

    public void setSubjectId(Integer subjectId) {
        this.subjectId = subjectId;
    }

    public Integer getScore() {
        return score;
    }

    public void setScore(Integer score) {
        this.score = score;
    }

    public Integer getGradeLevel() {
        return gradeLevel;
    }

    public void setGradeLevel(Integer gradeLevel) {
        this.gradeLevel = gradeLevel;
    }

    public Integer getDifficult() {
        return difficult;
    }

    public void setDifficult(Integer difficult) {
        this.difficult = difficult;
    }

    public String getCorrect() {
        return correct;
    }

    public void setCorrect(String correct) {
        this.correct = correct == null ? null : correct.trim();
    }

    public Integer getInfoTextContentId() {
        return infoTextContentId;
    }

    public void setInfoTextContentId(Integer infoTextContentId) {
        this.infoTextContentId = infoTextContentId;
    }

    public Integer getCreateUser() {
        return createUser;
    }

    public void setCreateUser(Integer createUser) {
        this.createUser = createUser;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Boolean getDeleted() {
        return deleted;
    }

    public void setDeleted(Boolean deleted) {
        this.deleted = deleted;
    }


    public void setCorrectFromVM(String correct, List<String> correctArray) {
        int qType = this.getQuestionType();
        //当前题目对象中获取题目类型（  questionType  ）

        if (qType == QuestionTypeEnum.MultipleChoice.getCode()) {
            String correctJoin = ExamUtil.contentToString(correctArray);
            this.setCorrect(correctJoin);
            //如果是多选题，调用  ExamUtil.contentToString  方法将  correctArray  列表中的答案数组转换为一个字符串。
            //将转换后的字符串设置为题目的正确答案。
        } else {
            this.setCorrect(correct);
        }
    }
}

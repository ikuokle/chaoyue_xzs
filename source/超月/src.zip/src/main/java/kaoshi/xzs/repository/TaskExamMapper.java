package xzs.repository;

//扩展了针对   TaskExam   实体的特定数据库操作方法。
// 它的主要功能包括：
// 通用数据库操作：继承自   BaseMapper   的增删改查方法。
// 分页查询：根据分页请求查询任务考试列表。
// 按年级级别查询：根据年级级别查询任务考试列表

import xzs.domain.TaskExam;
import xzs.viewmodel.admin.task.TaskPageRequestVM;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface TaskExamMapper extends BaseMapper<TaskExam> {

    List<TaskExam> page(TaskPageRequestVM requestVM);

    List<TaskExam> getByGradeLevel(Integer gradeLevel);
}

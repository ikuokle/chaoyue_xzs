package xzs.listener;

import xzs.domain.*;
import xzs.domain.enums.ExamPaperTypeEnum;
import xzs.domain.enums.QuestionTypeEnum;
import xzs.event.CalculateExamPaperAnswerCompleteEvent;
import xzs.service.ExamPaperAnswerService;
import xzs.service.ExamPaperQuestionCustomerAnswerService;
import xzs.service.TaskExamCustomerAnswerService;
import xzs.service.TextContentService;
import xzs.domain.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationListener;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.util.Date;
import java.util.List;

//Spring组件，它实现了   ApplicationListener   接口，
// 并监听   CalculateExamPaperAnswerCompleteEvent   事件。
// 当一个考试答案计算完成事件被发布时，
// 这个监听器将被触发，执行相关的业务逻辑，如更新考试答案、问题答案和文本内容

@Component
public class CalculateExamPaperAnswerListener implements ApplicationListener<CalculateExamPaperAnswerCompleteEvent> {

    private final ExamPaperAnswerService examPaperAnswerService;
    //用于操作考试答案的服务
    private final ExamPaperQuestionCustomerAnswerService examPaperQuestionCustomerAnswerService;
    //用于操作考试问题客户答案的服务
    private final TextContentService textContentService;
    //用于操作文本内容的服务
    private final TaskExamCustomerAnswerService examCustomerAnswerService;
    //用于操作任务考试客户答案的服务

    @Autowired
    public CalculateExamPaperAnswerListener(ExamPaperAnswerService examPaperAnswerService,
                   ExamPaperQuestionCustomerAnswerService examPaperQuestionCustomerAnswerService,
                   TextContentService textContentService,
                   TaskExamCustomerAnswerService examCustomerAnswerService) {
        this.examPaperAnswerService = examPaperAnswerService;
        this.examPaperQuestionCustomerAnswerService = examPaperQuestionCustomerAnswerService;
        this.textContentService = textContentService;
        this.examCustomerAnswerService = examCustomerAnswerService;
    }

    @Override
    @Transactional
    public void onApplicationEvent(CalculateExamPaperAnswerCompleteEvent
                                               calculateExamPaperAnswerCompleteEvent) {
        Date now = new Date();
        //获取当前日期和时间
        ExamPaperAnswerInfo examPaperAnswerInfo =
                (ExamPaperAnswerInfo) calculateExamPaperAnswerCompleteEvent.getSource();
        //从事件对象   calculateExamPaperAnswerCompleteEvent   中获取源对象，
        // 将其强制类型转换为   ExamPaperAnswerInfo   类型
        ExamPaper examPaper = examPaperAnswerInfo.getExamPaper();

        ExamPaperAnswer examPaperAnswer = examPaperAnswerInfo.getExamPaperAnswer();

        List<ExamPaperQuestionCustomerAnswer> examPaperQuestionCustomerAnswers =
                examPaperAnswerInfo.getExamPaperQuestionCustomerAnswers();
        //从   ExamPaperAnswerInfo   对象中分别获取考试试卷、考试答案和考试问题答案列表

        examPaperAnswerService.insertByFilter(examPaperAnswer);
        //调用   examPaperAnswerService   的   insertByFilter   方法插入或更新考试答案

        examPaperQuestionCustomerAnswers.stream().filter(a -> QuestionTypeEnum.
                needSaveTextContent(a.getQuestionType())).forEach(d -> {
            TextContent textContent = new TextContent(d.getAnswer(), now);
            textContentService.insertByFilter(textContent);
            d.setTextContentId(textContent.getId());
            d.setAnswer(d.getAnswer());
        });
        //遍历考试问题答案列表，筛选出需要保存文本内容的答案，
        // 创建   TextContent   对象并保存，然后更新问题答案列表中的答案内容

        examPaperQuestionCustomerAnswers.forEach(d -> {
            d.setExamPaperAnswerId(examPaperAnswer.getId());
        });
        //设置问题答案列表中每个答案的考试答案ID

        examPaperQuestionCustomerAnswerService.insertList(examPaperQuestionCustomerAnswers);

        switch (ExamPaperTypeEnum.fromCode(examPaper.getPaperType())) {
            case Task: {
                examCustomerAnswerService.insertOrUpdate(examPaper, examPaperAnswer, now);
                break;
            }
            default:
                break;
        }//根据考试试卷类型执行不同的逻辑，
        // 如果是任务考试，则调用   examCustomerAnswerService   的   insertOrUpdate   方法更新任务考试答案
    }
}

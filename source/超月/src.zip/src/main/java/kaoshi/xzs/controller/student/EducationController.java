package xzs.controller.student;


import xzs.base.BaseApiController;
import xzs.base.RestResponse;
import xzs.domain.Subject;
import xzs.domain.User;
import xzs.service.SubjectService;
import xzs.viewmodel.student.education.SubjectEditRequestVM;
import xzs.viewmodel.student.education.SubjectVM;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.stream.Collectors;

//是一个专门为学生设计的REST控制器，用于处理与教育相关的请求。
// 在这个版本中，控制器扩展自   BaseApiController  ，提供了获取学科列表和通过ID选择特定学科的端点。
// 这个控制器通过依赖注入   SubjectService   来执行业务逻辑，如获取学科信息。

@RestController("StudentEducationController")
@RequestMapping(value = "/api/student/education")
public class EducationController extends BaseApiController {

    private final SubjectService subjectService;

    @Autowired
    public EducationController(SubjectService subjectService) {
        this.subjectService = subjectService;
    }

    @RequestMapping(value = "/subject/list", method = RequestMethod.POST)
    public RestResponse<List<SubjectVM>> list() {
        User user = getCurrentUser();
        List<Subject> subjects = subjectService.getSubjectByLevel(user.getUserLevel());
        List<SubjectVM> subjectVMS = subjects.stream().map(d -> {
            SubjectVM subjectVM = modelMapper.map(d, SubjectVM.class);
            subjectVM.setId(String.valueOf(d.getId()));
            return subjectVM;
        }).collect(Collectors.toList());
        return RestResponse.ok(subjectVMS);
    }
    //处理 /api/student/education/subject/list 的 POST 请求，
    // 返回一个包含学科视图模型 SubjectVM 列表的响应

    @RequestMapping(value = "/subject/select/{id}", method = RequestMethod.POST)
    public RestResponse<SubjectEditRequestVM> select(@PathVariable Integer id) {
        Subject subject = subjectService.selectById(id);
        SubjectEditRequestVM vm = modelMapper.map(subject, SubjectEditRequestVM.class);
        return RestResponse.ok(vm);
    }
    //处理 /api/student/education/subject/select/{id} 的 POST 请求，
    // 根据给定的ID返回一个学科编辑请求视图模型 SubjectEditRequestVM

}

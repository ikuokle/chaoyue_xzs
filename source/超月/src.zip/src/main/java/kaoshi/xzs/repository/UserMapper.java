package xzs.repository;

//针对   User   实体的特定数据库操作方法。
// 它的主要功能包括：
// 通用数据库操作：继承自   BaseMapper   的增删改查方法。
// 用户查询：提供多种方式查询用户，包括按 ID、用户名、用户名和密码、UUID、微信 OpenID 等。
// 分页查询：支持分页查询用户列表。
// 批量操作：支持批量插入、更新和删除用户。
// 统计查询：统计用户数量和按用户名查询用户信息

import xzs.domain.other.KeyValue;
import xzs.domain.User;
import xzs.viewmodel.admin.user.UserPageRequestVM;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Map;


@Mapper
public interface UserMapper extends BaseMapper<User> {

    List<User> getAllUser();

    User getUserById(Integer id);

    User getUserByUserName(String username);

    User getUserByUserNamePwd(@Param("username") String username, @Param("pwd") String pwd);

    User getUserByUuid(String uuid);

    List<User> userPageList(Map<String, Object> map);

    Integer userPageCount(Map<String, Object> map);

    List<User> userPage(UserPageRequestVM requestVM);

    void insertUser(User user);

    void insertUsers(List<User> users);

    void updateUser(User user);

    void updateUsersAge(Map<String, Object> map);

    void deleteUsersByIds(List<Integer> ids);

    void insertUserSql(User user);

    Integer selectAllCount();

    List<KeyValue> selectByUserName(String userName);

    List<User> selectByIds(List<Integer> ids);


    User selectByWxOpenId(@Param("wxOpenId") String wxOpenId);
}

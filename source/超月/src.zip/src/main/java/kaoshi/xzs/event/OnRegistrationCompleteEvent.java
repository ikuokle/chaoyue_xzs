package xzs.event;

//表示用户注册完成后的事件

import xzs.domain.User;
import org.springframework.context.ApplicationEvent;


public class OnRegistrationCompleteEvent extends ApplicationEvent {
    private final User user;
    //封装用户注册完成后的详细信息，包括用户的基本信息（如用户名、密码、真实姓名等）

    public OnRegistrationCompleteEvent(final User user) {
        super(user);
        this.user = user;
    }

    public User getUser() {
        return user;
    }

}
package xzs.service;

import xzs.domain.ExamPaperAnswer;
import xzs.domain.ExamPaperAnswerInfo;
import xzs.domain.User;
import xzs.viewmodel.student.exam.ExamPaperSubmitVM;
import xzs.viewmodel.student.exampaper.ExamPaperAnswerPageVM;
import com.github.pagehelper.PageInfo;
import xzs.viewmodel.admin.paper.ExamPaperAnswerPageRequestVM;

import java.util.List;

public interface ExamPaperAnswerService extends BaseService<ExamPaperAnswer> {

    PageInfo<ExamPaperAnswer> studentPage(ExamPaperAnswerPageVM requestVM);

    ExamPaperAnswerInfo calculateExamPaperAnswer(ExamPaperSubmitVM examPaperSubmitVM, User user);

    String judge(ExamPaperSubmitVM examPaperSubmitVM);

    ExamPaperSubmitVM examPaperAnswerToVM(Integer id);

    Integer selectAllCount();

    List<Integer> selectMothCount();

    PageInfo<ExamPaperAnswer> adminPage(ExamPaperAnswerPageRequestVM requestVM);
}

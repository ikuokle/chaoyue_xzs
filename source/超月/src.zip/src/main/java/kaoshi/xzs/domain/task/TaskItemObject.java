package xzs.domain.task;

//一个任务项的基本信息

public class TaskItemObject {
    private Integer examPaperId;//试卷ID
    private String examPaperName;//试卷名称
    private Integer itemOrder;//任务项的顺序

    public Integer getExamPaperId() {
        return examPaperId;
    }

    public void setExamPaperId(Integer examPaperId) {
        this.examPaperId = examPaperId;
    }

    public String getExamPaperName() {
        return examPaperName;
    }

    public void setExamPaperName(String examPaperName) {
        this.examPaperName = examPaperName;
    }

    public Integer getItemOrder() {
        return itemOrder;
    }

    public void setItemOrder(Integer itemOrder) {
        this.itemOrder = itemOrder;
    }
}

package xzs.controller.student;

import xzs.base.BaseApiController;
import xzs.base.RestResponse;
import xzs.domain.ExamPaperQuestionCustomerAnswer;
import xzs.domain.Subject;
import xzs.domain.TextContent;
import xzs.domain.question.QuestionObject;
import xzs.service.ExamPaperQuestionCustomerAnswerService;
import xzs.service.QuestionService;
import xzs.service.SubjectService;
import xzs.service.TextContentService;
import xzs.utility.DateTimeUtil;
import xzs.utility.HtmlUtil;
import xzs.utility.JsonUtil;
import xzs.utility.PageInfoHelper;
import xzs.viewmodel.admin.question.QuestionEditRequestVM;
import xzs.viewmodel.student.exam.ExamPaperSubmitItemVM;
import xzs.viewmodel.student.question.answer.QuestionAnswerVM;
import xzs.viewmodel.student.question.answer.QuestionPageStudentRequestVM;
import xzs.viewmodel.student.question.answer.QuestionPageStudentResponseVM;
import com.github.pagehelper.PageInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

//Spring MVC控制器，它专门用于处理学生端的考试题目回答相关的请求。
// 这个控制器扩展自   BaseApiController  ，提供了获取题目回答列表和通过ID选择特定题目回答的端点。
// 它通过依赖注入   ExamPaperQuestionCustomerAnswerService  、
// QuestionService  、
// TextContentService   和   SubjectService   来执行题目相关的业务逻辑

@RestController("StudentQuestionAnswerController")
@RequestMapping(value = "/api/student/question/answer")
public class QuestionAnswerController extends BaseApiController {

    private final ExamPaperQuestionCustomerAnswerService examPaperQuestionCustomerAnswerService;
    //用于操作考试题目客户回答的服务
    private final QuestionService questionService;//用于操作题目的服务
    private final TextContentService textContentService;//用于操作文本内容的服务
    private final SubjectService subjectService;//用于操作学科的服务

    @Autowired
    public QuestionAnswerController(ExamPaperQuestionCustomerAnswerService examPaperQuestionCustomerAnswerService, QuestionService questionService, TextContentService textContentService, SubjectService subjectService) {
        this.examPaperQuestionCustomerAnswerService = examPaperQuestionCustomerAnswerService;
        this.questionService = questionService;
        this.textContentService = textContentService;
        this.subjectService = subjectService;
    }

    @RequestMapping(value = "/page", method = RequestMethod.POST)
    public RestResponse<PageInfo<QuestionPageStudentResponseVM>> pageList(@RequestBody QuestionPageStudentRequestVM model) {
        model.setCreateUser(getCurrentUser().getId());
        PageInfo<ExamPaperQuestionCustomerAnswer> pageInfo = examPaperQuestionCustomerAnswerService.studentPage(model);
        PageInfo<QuestionPageStudentResponseVM> page = PageInfoHelper.copyMap(pageInfo, q -> {
            Subject subject = subjectService.selectById(q.getSubjectId());
            QuestionPageStudentResponseVM vm = modelMapper.map(q, QuestionPageStudentResponseVM.class);
            vm.setCreateTime(DateTimeUtil.dateFormat(q.getCreateTime()));
            TextContent textContent = textContentService.selectById(q.getQuestionTextContentId());
            QuestionObject questionObject = JsonUtil.toJsonObject(textContent.getContent(), QuestionObject.class);
            String clearHtml = HtmlUtil.clear(questionObject.getTitleContent());
            vm.setShortTitle(clearHtml);
            vm.setSubjectName(subject.getName());
            return vm;
        });
        return RestResponse.ok(page);
    }//处理分页列出题目回答的请求


    @RequestMapping(value = "/select/{id}", method = RequestMethod.POST)
    public RestResponse<QuestionAnswerVM> select(@PathVariable Integer id) {
        QuestionAnswerVM vm = new QuestionAnswerVM();
        ExamPaperQuestionCustomerAnswer examPaperQuestionCustomerAnswer = examPaperQuestionCustomerAnswerService.selectById(id);
        ExamPaperSubmitItemVM questionAnswerVM = examPaperQuestionCustomerAnswerService.examPaperQuestionCustomerAnswerToVM(examPaperQuestionCustomerAnswer);
        QuestionEditRequestVM questionVM = questionService.getQuestionEditRequestVM(examPaperQuestionCustomerAnswer.getQuestionId());
        vm.setQuestionVM(questionVM);
        vm.setQuestionAnswerVM(questionAnswerVM);
        return RestResponse.ok(vm);
    }//处理根据给定ID选择特定题目回答的请求

}

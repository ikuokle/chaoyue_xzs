package xzs.configuration.property;

import org.springframework.boot.context.properties.ConfigurationProperties;

import java.util.List;
//集中管理应用程序的一些系统级别的配置信息

@ConfigurationProperties(prefix = "system")
/*这个类中的属性应该从配置文件中以   system   为前缀的属性中绑定值。
例如，在   application.properties   或   application.yml   文件中，
所有以   system.   开头的属性都将被映射到这个类中。*/

public class SystemConfig {

    private PasswordKeyConfig pwdKey;//存储密钥配置
    private List<String> securityIgnoreUrls;//指定不需要进行安全检查的路径

    public PasswordKeyConfig getPwdKey() {return pwdKey;}
    //获取密钥

    public void setPwdKey(PasswordKeyConfig pwdKey) {
        this.pwdKey = pwdKey;
    }
    //设置密钥

    public List<String> getSecurityIgnoreUrls() {
        return securityIgnoreUrls;
    }
    //获取不需要进行安全检查的路径

    public void setSecurityIgnoreUrls(List<String> securityIgnoreUrls) {
        this.securityIgnoreUrls = securityIgnoreUrls;
    }
    //设置不需要进行安全检查的路径

}

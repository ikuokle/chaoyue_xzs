package xzs.viewmodel.student.question.answer;

import xzs.base.BasePage;

public class QuestionPageStudentRequestVM extends BasePage {
    private Integer createUser;

    public Integer getCreateUser() {
        return createUser;
    }

    public void setCreateUser(Integer createUser) {
        this.createUser = createUser;
    }
}

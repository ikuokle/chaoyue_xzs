package xzs.controller.admin;


import xzs.base.BaseApiController;
import xzs.base.RestResponse;
import xzs.domain.Subject;
import xzs.service.SubjectService;
import xzs.utility.PageInfoHelper;
import xzs.viewmodel.admin.education.SubjectEditRequestVM;
import xzs.viewmodel.admin.education.SubjectPageRequestVM;
import xzs.viewmodel.admin.education.SubjectResponseVM;
import com.github.pagehelper.PageInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;

//Spring MVC控制器，专门用于处理与教育相关的管理操作，特别是学科（Subject）的管理。
// 这个控制器提供了一系列的RESTful API端点，
// 用于列出学科、分页显示学科、编辑学科信息、选择特定学科以及删除学科

@RestController("AdminEducationController")
@RequestMapping(value = "/api/admin/education")
//定义了类级别的请求映射，所有该控制器的方法都将在   /api/admin/education   路径下。
public class EducationController extends BaseApiController {

    private final SubjectService subjectService;//用于执行学科相关的业务逻辑

    @Autowired
    public EducationController(SubjectService subjectService) {
        this.subjectService = subjectService;
    }

    @RequestMapping(value = "/subject/list", method = RequestMethod.POST)
    public RestResponse<List<Subject>> list() {
        List<Subject> subjects = subjectService.allSubject();
        return RestResponse.ok(subjects);
    }//列出所有学科

    @RequestMapping(value = "/subject/page", method = RequestMethod.POST)
    public RestResponse<PageInfo<SubjectResponseVM>> pageList(@RequestBody SubjectPageRequestVM model) {
        PageInfo<Subject> pageInfo = subjectService.page(model);
        PageInfo<SubjectResponseVM> page = PageInfoHelper.copyMap(pageInfo, e -> modelMapper.map(e, SubjectResponseVM.class));
        return RestResponse.ok(page);
    }//分页查询学科

    @RequestMapping(value = "/subject/edit", method = RequestMethod.POST)
    public RestResponse edit(@RequestBody @Valid SubjectEditRequestVM model) {
        Subject subject = modelMapper.map(model, Subject.class);
        if (model.getId() == null) {
            subject.setDeleted(false);
            subjectService.insertByFilter(subject);
        } else {
            subjectService.updateByIdFilter(subject);
        }
        return RestResponse.ok();
    }//编辑学科信息

    @RequestMapping(value = "/subject/select/{id}", method = RequestMethod.POST)
    public RestResponse<SubjectEditRequestVM> select(@PathVariable Integer id) {
        Subject subject = subjectService.selectById(id);
        SubjectEditRequestVM vm = modelMapper.map(subject, SubjectEditRequestVM.class);
        return RestResponse.ok(vm);
    }//根据ID选择特定学科

    @RequestMapping(value = "/subject/delete/{id}", method = RequestMethod.POST)
    public RestResponse delete(@PathVariable Integer id) {
        Subject subject = subjectService.selectById(id);
        subject.setDeleted(true);
        subjectService.updateByIdFilter(subject);
        return RestResponse.ok();
    }//根据ID删除学科
}

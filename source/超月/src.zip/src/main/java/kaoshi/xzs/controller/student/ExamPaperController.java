package xzs.controller.student;

import xzs.base.BaseApiController;
import xzs.base.RestResponse;
import xzs.domain.ExamPaper;
import xzs.service.ExamPaperAnswerService;
import xzs.service.ExamPaperService;
import xzs.utility.DateTimeUtil;
import xzs.utility.PageInfoHelper;
import xzs.viewmodel.admin.exam.ExamPaperEditRequestVM;
import xzs.viewmodel.student.exam.ExamPaperPageResponseVM;
import xzs.viewmodel.student.exam.ExamPaperPageVM;
import com.github.pagehelper.PageInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

//一个Spring MVC控制器，专门为学生设计，用于处理与考试试卷相关的请求。
// 这个控制器扩展自   BaseApiController  ，
// 提供了获取考试试卷信息和分页列出考试试卷的端点。
// 它通过依赖注入   ExamPaperService 和   ExamPaperAnswerService 来执行考试试卷相关的业务逻辑，
// 同时使用   ApplicationEventPublisher   来发布应用事件

@RestController("StudentExamPaperController")
@RequestMapping(value = "/api/student/exam/paper")
public class ExamPaperController extends BaseApiController {

    private final ExamPaperService examPaperService;//用于操作考试试卷的服务
    private final ExamPaperAnswerService examPaperAnswerService;
    //用于操作考试答案的服务
    private final ApplicationEventPublisher eventPublisher;
    //用于发布应用事件

    @Autowired
    public ExamPaperController(ExamPaperService examPaperService, ExamPaperAnswerService examPaperAnswerService, ApplicationEventPublisher eventPublisher) {
        this.examPaperService = examPaperService;
        this.examPaperAnswerService = examPaperAnswerService;
        this.eventPublisher = eventPublisher;
    }


    @RequestMapping(value = "/select/{id}", method = RequestMethod.POST)
    public RestResponse<ExamPaperEditRequestVM> select(@PathVariable Integer id) {
        ExamPaperEditRequestVM vm = examPaperService.examPaperToVM(id);
        return RestResponse.ok(vm);
    }//处理根据给定ID选择特定考试试卷的请求


    @RequestMapping(value = "/pageList", method = RequestMethod.POST)
    public RestResponse<PageInfo<ExamPaperPageResponseVM>> pageList(@RequestBody @Valid ExamPaperPageVM model) {
        PageInfo<ExamPaper> pageInfo = examPaperService.studentPage(model);
        PageInfo<ExamPaperPageResponseVM> page = PageInfoHelper.copyMap(pageInfo, e -> {
            ExamPaperPageResponseVM vm = modelMapper.map(e, ExamPaperPageResponseVM.class);
            vm.setCreateTime(DateTimeUtil.dateFormat(e.getCreateTime()));
            return vm;
        });
        return RestResponse.ok(page);
    }//处理分页列出考试试卷的请求
}

package xzs.service.impl;

import xzs.domain.enums.ExamPaperAnswerStatusEnum;
import xzs.domain.enums.ExamPaperTypeEnum;
import xzs.domain.enums.QuestionTypeEnum;
import xzs.domain.exam.ExamPaperTitleItemObject;
import xzs.domain.other.KeyValue;
import xzs.domain.other.ExamPaperAnswerUpdate;
import xzs.domain.task.TaskItemAnswerObject;
import xzs.repository.*;
import xzs.repository.ExamPaperAnswerMapper;
import xzs.repository.ExamPaperMapper;
import xzs.repository.QuestionMapper;
import xzs.repository.TaskExamCustomerAnswerMapper;
import xzs.service.ExamPaperAnswerService;
import xzs.service.ExamPaperQuestionCustomerAnswerService;
import xzs.service.TextContentService;
import xzs.utility.DateTimeUtil;
import xzs.utility.ExamUtil;
import xzs.utility.JsonUtil;
import xzs.viewmodel.student.exam.ExamPaperSubmitItemVM;
import xzs.viewmodel.student.exam.ExamPaperSubmitVM;
import xzs.viewmodel.student.exampaper.ExamPaperAnswerPageVM;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import xzs.domain.*;
import xzs.domain.*;
import xzs.viewmodel.admin.paper.ExamPaperAnswerPageRequestVM;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

//专门处理与考试试卷题目客户答案（即学生答案）相关的业务逻辑。
// 此类通过使用   ExamPaperQuestionCustomerAnswerMapper   执行数据库操作，
// 并利用   TextContentService   来处理文本内容

@Service
public class ExamPaperAnswerServiceImpl extends BaseServiceImpl<ExamPaperAnswer> implements ExamPaperAnswerService {

    private final ExamPaperAnswerMapper examPaperAnswerMapper;
    //用于操作考试试卷数据库表的映射器
    private final ExamPaperMapper examPaperMapper;
    //用于操作问题数据库表的映射器
    private final TextContentService textContentService;
    //用于处理文本内容相关的业务逻辑，如获取文本内容
    private final QuestionMapper questionMapper;
    //
    private final ExamPaperQuestionCustomerAnswerService examPaperQuestionCustomerAnswerService;
    //用于与数据库交互，执行CRUD（创建、读取、更新、删除）操作
    private final TaskExamCustomerAnswerMapper taskExamCustomerAnswerMapper;
    //

    @Autowired
    public ExamPaperAnswerServiceImpl(ExamPaperAnswerMapper examPaperAnswerMapper, ExamPaperMapper examPaperMapper, TextContentService textContentService, QuestionMapper questionMapper, ExamPaperQuestionCustomerAnswerService examPaperQuestionCustomerAnswerService, TaskExamCustomerAnswerMapper taskExamCustomerAnswerMapper) {
        super(examPaperAnswerMapper);
        this.examPaperAnswerMapper = examPaperAnswerMapper;
        this.examPaperMapper = examPaperMapper;
        this.textContentService = textContentService;
        this.questionMapper = questionMapper;
        this.examPaperQuestionCustomerAnswerService = examPaperQuestionCustomerAnswerService;
        this.taskExamCustomerAnswerMapper = taskExamCustomerAnswerMapper;
    }

    @Override
    public PageInfo<ExamPaperAnswer> studentPage(ExamPaperAnswerPageVM requestVM) {
        return PageHelper.startPage(requestVM.getPageIndex(), requestVM.getPageSize(), "id desc").doSelectPageInfo(() ->
                examPaperAnswerMapper.studentPage(requestVM));
    }//处理分页查询考试试卷题目答案的请求


    @Override
    public ExamPaperAnswerInfo calculateExamPaperAnswer(ExamPaperSubmitVM examPaperSubmitVM,
                                                        User user) {
        ExamPaperAnswerInfo examPaperAnswerInfo = new ExamPaperAnswerInfo();
        //创建一个新的   ExamPaperAnswerInfo   实例，用于存储考试答案的相关信息
        Date now = new Date();
        // 获取当前日期和时间
        ExamPaper examPaper = examPaperMapper.selectByPrimaryKey(examPaperSubmitVM.getId());
        //根据   examPaperSubmitVM   中的 ID，通过   examPaperMapper   查询对应的考试试卷
        ExamPaperTypeEnum paperTypeEnum = ExamPaperTypeEnum.fromCode(examPaper.getPaperType());
        //从考试试卷中获取试卷类型，并尝试将其转换为   ExamPaperTypeEnum   枚举类型
        if (paperTypeEnum == ExamPaperTypeEnum.Task) {
            ExamPaperAnswer examPaperAnswer = examPaperAnswerMapper.getByPidUid(examPaperSubmitVM.getId(), user.getId());
            if (null != examPaperAnswer)
                return null;
        }//如果试卷类型是任务试卷（  Task  ），则检查用户是否已经做过这个任务试卷。如果是，则返回   null
        String frameTextContent = textContentService.selectById
                (examPaper.getFrameTextContentId()).getContent();
        //根据考试试卷的框架文本内容ID，通过   textContentService   查询对应的文本内容

        List<ExamPaperTitleItemObject> examPaperTitleItemObjects =
                JsonUtil.toJsonListObject(frameTextContent, ExamPaperTitleItemObject.class);
        //将框架文本内容转换为   ExamPaperTitleItemObject   列表

        List<Integer> questionIds = examPaperTitleItemObjects.stream().flatMap
                (t -> t.getQuestionItems().stream().map(q -> q.getId())).collect(Collectors.toList());
        //从   ExamPaperTitleItemObject   列表中提取所有题目的ID

        List<Question> questions = questionMapper.selectByIds(questionIds);
        //根据题目ID列表，通过   questionMapper   查询对应的题目列表

        List<ExamPaperQuestionCustomerAnswer> examPaperQuestionCustomerAnswers =
                examPaperTitleItemObjects.stream()
                .flatMap(t -> t.getQuestionItems().stream()
                        .map(q -> {
                            Question question = questions.stream().filter(tq -> tq.getId().equals(q.getId())).findFirst().get();
                            ExamPaperSubmitItemVM customerQuestionAnswer = examPaperSubmitVM.getAnswerItems().stream()
                                    .filter(tq -> tq.getQuestionId().equals(q.getId()))
                                    .findFirst()
                                    .orElse(null);
                            return ExamPaperQuestionCustomerAnswerFromVM(question, customerQuestionAnswer, examPaper, q.getItemOrder(), user, now);
                        })
                ).collect(Collectors.toList());
        //遍历   ExamPaperTitleItemObject   列表，
        // 对于每个题目项，找到对应的题目对象和用户的答案项（如果有的话），
        // 然后创建   ExamPaperQuestionCustomerAnswer   对象列表

        ExamPaperAnswer examPaperAnswer = ExamPaperAnswerFromVM
                (examPaperSubmitVM, examPaper, examPaperQuestionCustomerAnswers, user, now);
        //调用   ExamPaperAnswerFromVM   方法，
        // 根据提交的答案视图模型（  examPaperSubmitVM  ），
        // 考试试卷对象（  examPaper  ），题目答案列表（  examPaperQuestionCustomerAnswers  ），
        // 当前用户（  user  ）和当前时间（  now  ）来创建   ExamPaperAnswer   对象

        examPaperAnswerInfo.setExamPaper(examPaper);
        examPaperAnswerInfo.setExamPaperAnswer(examPaperAnswer);
        examPaperAnswerInfo.setExamPaperQuestionCustomerAnswers(examPaperQuestionCustomerAnswers);
        return examPaperAnswerInfo;
        //设置   ExamPaperAnswerInfo   对象的属性，
        // 包括考试试卷，考试答案和题目答案列表，然后返回这个对象
    }

    @Override
    @Transactional
    public String judge(ExamPaperSubmitVM examPaperSubmitVM) {
        ExamPaperAnswer examPaperAnswer = examPaperAnswerMapper.selectByPrimaryKey
                (examPaperSubmitVM.getId());
        //使用   examPaperAnswerMapper   通过主键（即考试答案的ID）查询数据库，
        // 获取对应的   ExamPaperAnswer   对象
        List<ExamPaperSubmitItemVM> judgeItems =
                examPaperSubmitVM.getAnswerItems().stream().filter(d -> d.getDoRight() == null).collect(Collectors.toList());
        //从   examPaperSubmitVM   中获取答案项列表，
        // 使用流（Stream）过滤出那些   DoRight  （即是否正确）为空的答案项，这些是需要评分的答案项
        List<ExamPaperAnswerUpdate> examPaperAnswerUpdates = new ArrayList<>(judgeItems.size());
        //创建一个   ArrayList  ，用于存储答案的更新信息，其大小初始化为需要评分的答案项的数量

        Integer customerScore = examPaperAnswer.getUserScore();
        Integer questionCorrect = examPaperAnswer.getQuestionCorrect();
        //获取当前考试答案的分数和正确题目数

        for (ExamPaperSubmitItemVM d : judgeItems) {
            ExamPaperAnswerUpdate examPaperAnswerUpdate = new ExamPaperAnswerUpdate();
            examPaperAnswerUpdate.setId(d.getId());
            examPaperAnswerUpdate.setCustomerScore(ExamUtil.scoreFromVM(d.getScore()));
            boolean doRight = examPaperAnswerUpdate.getCustomerScore().equals(ExamUtil.scoreFromVM(d.getQuestionScore()));
            examPaperAnswerUpdate.setDoRight(doRight);
            examPaperAnswerUpdates.add(examPaperAnswerUpdate);
            customerScore += examPaperAnswerUpdate.getCustomerScore();
            if (examPaperAnswerUpdate.getDoRight()) {
                ++questionCorrect;
            }
        }//遍历每个需要评分的答案项，
        // 创建一个   ExamPaperAnswerUpdate   对象来存储更新信息，包括答案项的ID、分数和是否正确

        examPaperAnswer.setUserScore(customerScore);
        examPaperAnswer.setQuestionCorrect(questionCorrect);
        examPaperAnswer.setStatus(ExamPaperAnswerStatusEnum.Complete.getCode());
        examPaperAnswerMapper.updateByPrimaryKeySelective(examPaperAnswer);
        //更新   examPaperAnswer   对象的用户分数、正确题目数和状态，
        // 然后通过   examPaperAnswerMapper   更新数据库中的记录

        examPaperQuestionCustomerAnswerService.updateScore(examPaperAnswerUpdates);
        //调用   examPaperQuestionCustomerAnswerService   的   updateScore   方法批量更新答案分数

        ExamPaperTypeEnum examPaperTypeEnum = ExamPaperTypeEnum.fromCode(examPaperAnswer.getPaperType());
        switch (examPaperTypeEnum) {
            case Task:
                //任务试卷批改完成后，需要更新任务的状态
                ExamPaper examPaper = examPaperMapper.selectByPrimaryKey(examPaperAnswer.getExamPaperId());
                Integer taskId = examPaper.getTaskExamId();
                Integer userId = examPaperAnswer.getCreateUser();
                TaskExamCustomerAnswer taskExamCustomerAnswer = taskExamCustomerAnswerMapper.getByTUid(taskId, userId);
                TextContent textContent = textContentService.selectById(taskExamCustomerAnswer.getTextContentId());
                List<TaskItemAnswerObject> taskItemAnswerObjects = JsonUtil.toJsonListObject(textContent.getContent(), TaskItemAnswerObject.class);
                taskItemAnswerObjects.stream()
                        .filter(d -> d.getExamPaperAnswerId().equals(examPaperAnswer.getId()))
                        .findFirst().ifPresent(taskItemAnswerObject -> taskItemAnswerObject.setStatus(examPaperAnswer.getStatus()));
                textContentService.jsonConvertUpdate(textContent, taskItemAnswerObjects, null);
                textContentService.updateByIdFilter(textContent);
                break;
            default:
                break;
        }
        //根据试卷类型执行不同的逻辑。如果是任务考试，则获取任务考试对象，
        // 更新任务考试答案的状态，并将更新后的内容保存回数据库
        return ExamUtil.scoreToVM(customerScore);
    }//处理学生提交的考试答案，进行评分，并根据评分结果更新数据库中的相关记录

    @Override
    public ExamPaperSubmitVM examPaperAnswerToVM(Integer id) {
        ExamPaperSubmitVM examPaperSubmitVM = new ExamPaperSubmitVM();
        //创建一个新的   ExamPaperSubmitVM   对象，用于存储转换后的数据
        ExamPaperAnswer examPaperAnswer = examPaperAnswerMapper.selectByPrimaryKey(id);
        //使用   examPaperAnswerMapper   通过主键ID从数据库中查询对应的   ExamPaperAnswer   实体
        examPaperSubmitVM.setId(examPaperAnswer.getId());
        examPaperSubmitVM.setDoTime(examPaperAnswer.getDoTime());
        examPaperSubmitVM.setScore(ExamUtil.scoreToVM(examPaperAnswer.getUserScore()));
        //设置   ExamPaperSubmitVM   对象的   id  、  doTime   和   score   属性，
        // 分别从   ExamPaperAnswer   实体中获取
        List<ExamPaperQuestionCustomerAnswer> examPaperQuestionCustomerAnswers
                = examPaperQuestionCustomerAnswerService.selectListByPaperAnswerId
                (examPaperAnswer.getId());
        //调用   examPaperQuestionCustomerAnswerService   的   selectListByPaperAnswerId   方法，
        // 根据考试答案ID查询相关的题目答案列表
        List<ExamPaperSubmitItemVM> examPaperSubmitItemVMS =
                examPaperQuestionCustomerAnswers.stream()
                .map(a -> examPaperQuestionCustomerAnswerService.examPaperQuestionCustomerAnswerToVM(a))
                .collect(Collectors.toList());
        //使用流（Stream）处理题目答案列表，
        // 将每个   ExamPaperQuestionCustomerAnswer   对象转换为   ExamPaperSubmitItemVM   对象，然后收集到列表中
        examPaperSubmitVM.setAnswerItems(examPaperSubmitItemVMS);
        //将转换后的题目答案列表设置到   ExamPaperSubmitVM   对象的   answerItems   属性中
        return examPaperSubmitVM;
    }//它负责将数据库中的   ExamPaperAnswer   实体转换为前端所需的   ExamPaperSubmitVM   视图模型（ViewModel）

    @Override
    public Integer selectAllCount() {
        return examPaperAnswerMapper.selectAllCount();
    }
    //用来统计答题记录的总数

    @Override
    public List<Integer> selectMothCount() {
        Date startTime = DateTimeUtil.getMonthStartDay();
        Date endTime = DateTimeUtil.getMonthEndDay();
        List<KeyValue> mouthCount = examPaperAnswerMapper.selectCountByDate(startTime, endTime);
        List<String> mothStartToNowFormat = DateTimeUtil.MothStartToNowFormat();
        return mothStartToNowFormat.stream().map(md -> {
            KeyValue keyValue = mouthCount.stream().filter(kv -> kv.getName().equals(md)).findAny().orElse(null);
            return null == keyValue ? 0 : keyValue.getValue();
        }).collect(Collectors.toList());
    }//查询每月题目答案的数量


    private ExamPaperQuestionCustomerAnswer ExamPaperQuestionCustomerAnswerFromVM(Question question, ExamPaperSubmitItemVM customerQuestionAnswer, ExamPaper examPaper, Integer itemOrder, User user, Date now) {
        ExamPaperQuestionCustomerAnswer examPaperQuestionCustomerAnswer = new ExamPaperQuestionCustomerAnswer();
        //创建一个新的  ExamPaperQuestionCustomerAnswer  对象，用于存储学生提交的题目答案

        examPaperQuestionCustomerAnswer.setQuestionId(question.getId());
        //从  Question  对象中获取题目ID

        examPaperQuestionCustomerAnswer.setExamPaperId(examPaper.getId());
        //从  ExamPaper  对象中获取试卷ID

        examPaperQuestionCustomerAnswer.setQuestionScore(question.getScore());
        //从  Question  对象中获取题目分数

        examPaperQuestionCustomerAnswer.setSubjectId(examPaper.getSubjectId());
        //从  ExamPaper  对象中获取科目ID

        examPaperQuestionCustomerAnswer.setItemOrder(itemOrder);
        //从方法参数中获取题目在试卷中的顺序

        examPaperQuestionCustomerAnswer.setCreateTime(now);
        //从方法参数中获取当前时间

        examPaperQuestionCustomerAnswer.setCreateUser(user.getId());
        //从  User  对象中获取用户ID

        examPaperQuestionCustomerAnswer.setQuestionType(question.getQuestionType());
        //从  Question  对象中获取题目类型

        examPaperQuestionCustomerAnswer.setQuestionTextContentId(question.getInfoTextContentId());
        //从  Question  对象中获取题目文本内容ID

        if (null == customerQuestionAnswer) {
            examPaperQuestionCustomerAnswer.setCustomerScore(0);
            //如果  customerQuestionAnswer  为  null  ，表示学生没有提交答案，设置学生得分为  0
        } else {
            setSpecialFromVM(examPaperQuestionCustomerAnswer, question, customerQuestionAnswer);
            //如果  customerQuestionAnswer  不为  null  ，
            // 调用  setSpecialFromVM  方法，根据题目类型处理学生提交的答案
        }
        return examPaperQuestionCustomerAnswer;
    }
    //将学生提交的题目答案视图模型（  ExamPaperSubmitItemVM  ）
    // 转换为一个  ExamPaperQuestionCustomerAnswer  对象


    private void setSpecialFromVM(ExamPaperQuestionCustomerAnswer examPaperQuestionCustomerAnswer,//学生提交的题目答案对象
                                  Question question, //题目对象，包含题目的基本信息
                                  ExamPaperSubmitItemVM customerQuestionAnswer//学生提交的题目答案视图模型
    ) {
        QuestionTypeEnum questionTypeEnum = QuestionTypeEnum.fromCode(examPaperQuestionCustomerAnswer.getQuestionType());
        //从  examPaperQuestionCustomerAnswer  对象中获取题目类型代码，
        // 并通过  QuestionTypeEnum.fromCode  方法将其转换为枚举类型  QuestionTypeEnum

        switch (questionTypeEnum) {
            case SingleChoice:
            case TrueFalse:
                examPaperQuestionCustomerAnswer.setAnswer(customerQuestionAnswer.getContent());
                //从  customerQuestionAnswer.getContent()  获取学生提交的答案，
                // 并将其设置到  examPaperQuestionCustomerAnswer  对象中

                examPaperQuestionCustomerAnswer.setDoRight(question.getCorrect().equals(customerQuestionAnswer.getContent()));
                //比较学生提交的答案和题目正确答案（  question.getCorrect()  ），
                // 并将结果设置到  examPaperQuestionCustomerAnswer  对象的  doRight  属性中

                examPaperQuestionCustomerAnswer.setCustomerScore(examPaperQuestionCustomerAnswer.getDoRight() ? question.getScore() : 0);
                //如果答对（  doRight  为  true  ），
                // 则设置学生得分为题目满分（  question.getScore()  ）；否则设置为  0

                break;
            case MultipleChoice:
                String customerAnswer = ExamUtil.contentToString(customerQuestionAnswer.getContentArray());
                //使用  ExamUtil.contentToString  方法将学生提交的多选题答案数组（  customerQuestionAnswer.getContentArray()  ）转换为字符串

                examPaperQuestionCustomerAnswer.setAnswer(customerAnswer);
                //将转换后的答案字符串设置到  examPaperQuestionCustomerAnswer  对象中

                examPaperQuestionCustomerAnswer.setDoRight(customerAnswer.equals(question.getCorrect()));
                //比较学生提交的答案字符串和题目正确答案字符串（  question.getCorrect()  ），
                // 并将结果设置到  examPaperQuestionCustomerAnswer  对象的  doRight  属性中

                examPaperQuestionCustomerAnswer.setCustomerScore(examPaperQuestionCustomerAnswer.getDoRight() ? question.getScore() : 0);
                //如果答对（  doRight  为  true  ），则设置学生得分为题目满分（  question.getScore()  ）；否则设置为  0

                break;
            case GapFilling:
                String correctAnswer = JsonUtil.toJsonStr(customerQuestionAnswer.getContentArray());
                //使用  JsonUtil.toJsonStr  方法将学生提交的填空题答案数组（  customerQuestionAnswer.getContentArray()  ）转换为JSON字符串

                examPaperQuestionCustomerAnswer.setAnswer(correctAnswer);
                //将转换后的答案字符串设置到  examPaperQuestionCustomerAnswer  对象中

                examPaperQuestionCustomerAnswer.setCustomerScore(0);
                //填空题的分数默认设置为  0  ，具体的评分逻辑可能需要在后续步骤中处理
                break;

            default:
                examPaperQuestionCustomerAnswer.setAnswer(customerQuestionAnswer.getContent());
                //对于其他类型的题目，直接将学生提交的答案（  customerQuestionAnswer.getContent()  ）
                // 设置到  examPaperQuestionCustomerAnswer  对象中

                examPaperQuestionCustomerAnswer.setCustomerScore(0);
                //默认情况下，分数设置为  0

                break;
        }
    }

    private ExamPaperAnswer ExamPaperAnswerFromVM(ExamPaperSubmitVM examPaperSubmitVM, ExamPaper examPaper, List<ExamPaperQuestionCustomerAnswer> examPaperQuestionCustomerAnswers, User user, Date now) {
        Integer systemScore = examPaperQuestionCustomerAnswers.stream().mapToInt(a -> a.getCustomerScore()).sum();
        long questionCorrect = examPaperQuestionCustomerAnswers.stream().filter(a -> a.getCustomerScore().equals(a.getQuestionScore())).count();
        ExamPaperAnswer examPaperAnswer = new ExamPaperAnswer();
        examPaperAnswer.setPaperName(examPaper.getName());
        examPaperAnswer.setDoTime(examPaperSubmitVM.getDoTime());
        examPaperAnswer.setExamPaperId(examPaper.getId());
        examPaperAnswer.setCreateUser(user.getId());
        examPaperAnswer.setCreateTime(now);
        examPaperAnswer.setSubjectId(examPaper.getSubjectId());
        examPaperAnswer.setQuestionCount(examPaper.getQuestionCount());
        examPaperAnswer.setPaperScore(examPaper.getScore());
        examPaperAnswer.setPaperType(examPaper.getPaperType());
        examPaperAnswer.setSystemScore(systemScore);
        examPaperAnswer.setUserScore(systemScore);
        examPaperAnswer.setTaskExamId(examPaper.getTaskExamId());
        examPaperAnswer.setQuestionCorrect((int) questionCorrect);
        boolean needJudge = examPaperQuestionCustomerAnswers.stream().anyMatch(d -> QuestionTypeEnum.needSaveTextContent(d.getQuestionType()));
        if (needJudge) {
            examPaperAnswer.setStatus(ExamPaperAnswerStatusEnum.WaitJudge.getCode());
        } else {
            examPaperAnswer.setStatus(ExamPaperAnswerStatusEnum.Complete.getCode());
        }
        return examPaperAnswer;
    }


    @Override
    public PageInfo<ExamPaperAnswer> adminPage(ExamPaperAnswerPageRequestVM requestVM) {
        return PageHelper.startPage(requestVM.getPageIndex(), requestVM.getPageSize(), "id desc").doSelectPageInfo(() ->
                examPaperAnswerMapper.adminPage(requestVM));
    }
}

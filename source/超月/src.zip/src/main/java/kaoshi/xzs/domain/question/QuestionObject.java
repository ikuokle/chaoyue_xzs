package xzs.domain.question;

//表示一个题目的完整信息

import java.util.List;
public class QuestionObject {

    private String titleContent;//题目的标题或问题内容

    private String analyze;//题目的解析或答案分析

    private List<QuestionItemObject> questionItemObjects;//题目的选项列表

    private String correct;//题目的正确答案

    public String getTitleContent() {
        return titleContent;
    }

    public void setTitleContent(String titleContent) {
        this.titleContent = titleContent;
    }

    public String getAnalyze() {
        return analyze;
    }

    public void setAnalyze(String analyze) {
        this.analyze = analyze;
    }

    public List<QuestionItemObject> getQuestionItemObjects() {
        return questionItemObjects;
    }

    public void setQuestionItemObjects(List<QuestionItemObject> questionItemObjects) {
        this.questionItemObjects = questionItemObjects;
    }

    public String getCorrect() {
        return correct;
    }

    public void setCorrect(String correct) {
        this.correct = correct;
    }
}

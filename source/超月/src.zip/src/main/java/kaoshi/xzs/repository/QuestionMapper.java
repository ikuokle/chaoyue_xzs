package xzs.repository;

//扩展了针对   Question   实体的特定数据库操作方法。
// 它的主要功能包括：
// 通用数据库操作：继承自   BaseMapper   的增删改查方法。
// 分页查询：提供分页查询功能。
// 批量查询：根据 ID 列表查询题目。
// 统计查询：按日期范围统计题目的数量

import xzs.domain.other.KeyValue;
import xzs.domain.Question;
import xzs.viewmodel.admin.question.QuestionPageRequestVM;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.Date;
import java.util.List;

@Mapper
public interface QuestionMapper extends BaseMapper<Question> {

    List<Question> page(QuestionPageRequestVM requestVM);

    List<Question> selectByIds(@Param("ids") List<Integer> ids);

    Integer selectAllCount();

    List<KeyValue> selectCountByDate(@Param("startTime") Date startTime, @Param("endTime") Date endTime);
}

package xzs.exception;

//用于表示业务逻辑中的异常情况，例如用户输入错误、业务规则违反等

public class BusinessException extends RuntimeException {
    public static final int UNKNOWN_EXCEPTION = 0;
    //表示未知或未分类的异常情况

    private int code;
    //提供一个整数代码来标识具体的异常类型，便于在业务逻辑中进行更精确的异常处理

    public BusinessException() {
        super();
    }

    public BusinessException(String message, Throwable cause) {
        super(message, cause);
    }
    // message  ：异常消息。cause  ：异常原因

    public BusinessException(String message) {
        super(message);
    }


    public BusinessException(Throwable cause) {
        super(cause);
    }

    public BusinessException(int code) {
        super();
        this.code = code;
    }


    public BusinessException(int code, String message, Throwable cause) {
        super(message, cause);
        this.code = code;
    }

    public BusinessException(int code, String message) {
        super(message);
        this.code = code;
    }

    public BusinessException(int code, Throwable cause) {
        super(cause);
        this.code = code;
    }


    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }


    public boolean isUnknown() {
        return code == UNKNOWN_EXCEPTION;
    }


}

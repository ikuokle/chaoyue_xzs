package xzs.service.impl;

//实现了   TextContentService   接口的服务类，专门处理与文本内容相关的业务逻辑。
// 它的主要功能包括：
// 1. 通用数据库操作：继承自   BaseServiceImpl   的增删改查方法。
// 2. JSON 数据转换：将对象列表转换为 JSON 字符串，并保存到文本内容中。
// 3. 更新 JSON 数据：更新文本内容中的 JSON 数据

import xzs.domain.TextContent;
import xzs.repository.TextContentMapper;
import xzs.service.TextContentService;
import xzs.utility.JsonUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;
import java.util.function.Function;
import java.util.stream.Collectors;

@Service
public class TextContentServiceImpl extends BaseServiceImpl<TextContent> implements TextContentService {

    private final TextContentMapper textContentMapper;

    @Autowired
    public TextContentServiceImpl(TextContentMapper textContentMapper) {
        super(textContentMapper);
        this.textContentMapper = textContentMapper;
    }

    @Override
    public TextContent selectById(Integer id) {
        return super.selectById(id);
    }

    @Override
    public int insertByFilter(TextContent record) {
        return super.insertByFilter(record);
    }

    @Override
    public int updateByIdFilter(TextContent record) {
        return super.updateByIdFilter(record);
    }

    @Override
    public <T, R> TextContent jsonConvertInsert(List<T> list, Date now, Function<? super T, ? extends R> mapper) {
        String frameTextContent = null;
        if (null == mapper) {
            frameTextContent = JsonUtil.toJsonStr(list);
        } else {
            List<R> mapList = list.stream().map(mapper).collect(Collectors.toList());
            frameTextContent = JsonUtil.toJsonStr(mapList);
        }
        TextContent textContent = new TextContent(frameTextContent, now);
        return textContent;
    }//将对象列表转换为 JSON 字符串，并创建新的   TextContent   对象。

    @Override
    public <T, R> TextContent jsonConvertUpdate(TextContent textContent, List<T> list, Function<? super T, ? extends R> mapper) {
        String frameTextContent = null;
        if (null == mapper) {
            frameTextContent = JsonUtil.toJsonStr(list);
        } else {
            List<R> mapList = list.stream().map(mapper).collect(Collectors.toList());
            frameTextContent = JsonUtil.toJsonStr(mapList);
        }
        textContent.setContent(frameTextContent);
        return textContent;
    }//更新文本内容中的 JSON 数据。



}

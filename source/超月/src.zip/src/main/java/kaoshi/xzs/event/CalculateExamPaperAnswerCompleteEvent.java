package xzs.event;

//表示试卷答题完成后的计算事件

import xzs.domain.ExamPaperAnswerInfo;
import org.springframework.context.ApplicationEvent;


public class CalculateExamPaperAnswerCompleteEvent extends ApplicationEvent {
    private final ExamPaperAnswerInfo examPaperAnswerInfo;
    //封装试卷答题完成后的详细信息，包括试卷信息、答题记录和题目答案等

    public CalculateExamPaperAnswerCompleteEvent(final ExamPaperAnswerInfo examPaperAnswerInfo) {
        super(examPaperAnswerInfo);
        this.examPaperAnswerInfo = examPaperAnswerInfo;
    }

    public ExamPaperAnswerInfo getExamPaperAnswerInfo() {
        return examPaperAnswerInfo;
    }

}

package xzs.repository;

//通用数据库操作：继承自   BaseMapper   的增删改查方法。
// 分页查询：提供学生端和管理员端的分页查询功能。
// 统计查询：按日期范围统计答题记录的数量。
// 特定记录查询：根据试卷 ID 和用户 ID 查询特定的答题记录。

import xzs.domain.ExamPaperAnswer;
import xzs.domain.other.KeyValue;
import xzs.viewmodel.student.exampaper.ExamPaperAnswerPageVM;
import xzs.viewmodel.admin.paper.ExamPaperAnswerPageRequestVM;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.Date;
import java.util.List;

@Mapper
public interface ExamPaperAnswerMapper extends BaseMapper<ExamPaperAnswer> {

    List<ExamPaperAnswer> studentPage(ExamPaperAnswerPageVM requestVM);
    //查询到的答题记录列表

    Integer selectAllCount();
    //查询所有答题记录的总数

    List<KeyValue> selectCountByDate(@Param("startTime") Date startTime, @Param("endTime") Date endTime);
    //根据时间范围查询答题记录的数量统计

    ExamPaperAnswer getByPidUid(@Param("pid") Integer paperId, @Param("uid") Integer uid);
    //根据试卷 ID 和用户 ID 查询特定的答题记录

    List<ExamPaperAnswer> adminPage(ExamPaperAnswerPageRequestVM requestVM);
    //根据管理员端的分页请求查询答题记录

}

package xzs.configuration.spring.security;

import xzs.domain.enums.RoleEnum;
import xzs.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Component;

import java.util.ArrayList;

//加载用户信息，并将其转换为 Spring Security 可以理解的格式，以便进行身份验证和授权

@Component
public class RestDetailsServiceImpl implements UserDetailsService {

    private final UserService userService;

    @Autowired
    public RestDetailsServiceImpl(UserService userService) {
        this.userService = userService;
    }

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {

        xzs.domain.User user = userService.getUserByUserName(username);

        if (user == null) {
            throw new UsernameNotFoundException("Username  not found.");
        }

        ArrayList<GrantedAuthority> grantedAuthorities = new ArrayList<>();
        grantedAuthorities.add(new SimpleGrantedAuthority(RoleEnum.fromCode(user.getRole()).getRoleName()));

        return new User(user.getUserName(), user.getPassword(), grantedAuthorities);
    }//根据用户名加载用户信息
    /*1. 查询用户信息：使用注入的   UserService   通过用户名查询用户信息。
    2. 检查用户是否存在：如果用户不存在，抛出   UsernameNotFoundException   异常。
    3. 创建权限列表：根据用户的角色创建一个权限列表（  GrantedAuthority  ），这里使用   SimpleGrantedAuthority   来封装角色名称。
    4. 创建 UserDetails 对象：使用用户的用户名、密码和权限列表创建一个   User   对象，该对象实现了   UserDetails   接口。
    5. 返回 UserDetails 对象：返回创建的   User   对象，Spring Security 使用此对象进行身份验证和授权。*/
}

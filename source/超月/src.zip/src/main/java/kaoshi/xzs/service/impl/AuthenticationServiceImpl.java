package xzs.service.impl;

//实现了用户认证逻辑
// 它通过依赖注入获取用户服务和系统配置，使用 RSA 算法对用户密码进行加密和解密。
// 该类提供了以下功能：
// 验证用户名和密码是否正确。
// 提供密码加密和解密的方法

import xzs.configuration.property.SystemConfig;
import xzs.domain.User;
import xzs.service.AuthenticationService;
import xzs.service.UserService;
import xzs.utility.RsaUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


@Service
public class AuthenticationServiceImpl implements AuthenticationService {


    private final UserService userService;//用于访问用户相关的数据操作
    private final SystemConfig systemConfig;//用于获取系统配置，特别是 RSA 密钥

    @Autowired
    public AuthenticationServiceImpl(UserService userService, SystemConfig systemConfig) {
        this.userService = userService;
        this.systemConfig = systemConfig;
    }

    @Override
    public boolean authUser(String username, String password) {
        User user = userService.getUserByUserName(username);
        return authUser(user, username, password);
    }//根据用户名和密码验证用户


    @Override
    public boolean authUser(User user, String username, String password) {
        if (user == null) {
            return false;
        }
        String encodePwd = user.getPassword();
        if (null == encodePwd || encodePwd.length() == 0) {
            return false;
        }
        String pwd = pwdDecode(encodePwd);
        return pwd.equals(password);
    }//验证用户对象的密码是否正确

    @Override
    public String pwdEncode(String password) {
        return RsaUtil.rsaEncode(systemConfig.getPwdKey().getPublicKey(), password);
    }//使用 RSA 公钥对密码进行加密

    @Override
    public String pwdDecode(String encodePwd) {
        return RsaUtil.rsaDecode(systemConfig.getPwdKey().getPrivateKey(), encodePwd);
    }//使用 RSA 私钥对密码进行解密


}

package xzs.domain.exam;

//标题项。
// 它主要包含两个属性：1. 标题名称（  name  ）2. 题目列表（  questionItems  ）：属于该标题下的所有题目。

import java.util.List;

public class ExamPaperTitleItemObject {

    private String name;

    private List<ExamPaperQuestionItemObject> questionItems;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public List<ExamPaperQuestionItemObject> getQuestionItems() {
        return questionItems;
    }

    public void setQuestionItems(List<ExamPaperQuestionItemObject> questionItems) {
        this.questionItems = questionItems;
    }
}

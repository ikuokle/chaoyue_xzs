package xzs.domain;

//学生对任务考试的答题记录

import java.io.Serializable;
import java.util.Date;

public class TaskExamCustomerAnswer implements Serializable {
    private Integer id;// 答题记录ID

    private Integer taskExamId;// 任务考试ID

    private Integer createUser;// 创建者（学生）ID

    private Date createTime;// 答题时间

    private Integer textContentId;// 任务完成情况内容ID

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getTaskExamId() {
        return taskExamId;
    }

    public void setTaskExamId(Integer taskExamId) {
        this.taskExamId = taskExamId;
    }

    public Integer getCreateUser() {
        return createUser;
    }

    public void setCreateUser(Integer createUser) {
        this.createUser = createUser;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Integer getTextContentId() {
        return textContentId;
    }

    public void setTextContentId(Integer textContentId) {
        this.textContentId = textContentId;
    }
}

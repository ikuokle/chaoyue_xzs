package xzs.context;

import xzs.domain.User;
import xzs.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.RequestAttributes;
import org.springframework.web.context.request.RequestContextHolder;

//在 Web 应用中管理和获取当前用户的上下文信息
@Component
public class WebContext {
    private static final String USER_ATTRIBUTES = "USER_ATTRIBUTES";//存储当前用户的信息
    private final UserService userService;//通过用户名获取用户详细信息

    @Autowired
    public WebContext(UserService userService) {
        this.userService = userService;
    }


    public void setCurrentUser(User user) {
        RequestContextHolder.currentRequestAttributes().setAttribute(USER_ATTRIBUTES, user,
                RequestAttributes.SCOPE_REQUEST);
    }//将用户信息存储在请求属性中，以便在同一个请求的其他部分可以访问

    public User getCurrentUser() {
        User user = (User) RequestContextHolder.currentRequestAttributes().getAttribute(USER_ATTRIBUTES,
                RequestAttributes.SCOPE_REQUEST);//从请求属性中获取当前用户
        if (null != user) {
            return user;
        } else {
            org.springframework.security.core.userdetails.User springUser = (org.springframework.
                    security.core.userdetails.User) SecurityContextHolder.getContext().
                    getAuthentication().getPrincipal();
            if (null == springUser) {
                return null;
            }
            user = userService.getUserByUserName(springUser.getUsername());
            //使用   UserService   通过用户名获取用户详细信息
            if (null != user) {
                setCurrentUser(user);
            }
            return user;
        }
    }
}

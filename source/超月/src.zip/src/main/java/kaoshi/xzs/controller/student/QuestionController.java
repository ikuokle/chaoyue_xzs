package xzs.controller.student;

import xzs.base.BaseApiController;
import xzs.service.QuestionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

//Spring MVC控制器，专门为学生设计，用于处理与问题（Question）相关的请求。
// 这个控制器扩展自   BaseApiController  ，
// 提供了一个基础的框架来构建API端点，用于执行与问题相关的操作

@RestController("StudentQuestionController")
@RequestMapping(value = "/api/student/question")
public class QuestionController extends BaseApiController {

    private final QuestionService questionService;

    @Autowired
    public QuestionController(QuestionService questionService) {
        this.questionService = questionService;
    }
}

package xzs.configuration.property;

//集中管理 Cookie 的配置
public class CookieConfig {

    public static String getName() {
        return "koala";
    }
    //Cookie 的名称被设置

    public static Integer getInterval() {
        return 30 * 24 * 60 * 60;
    }
    //个设置决定了 Cookie 在浏览器中存储的时间长度
}

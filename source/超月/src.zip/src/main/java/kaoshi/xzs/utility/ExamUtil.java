package xzs.utility;

//工具类，提供了与考试相关的一些常用工具方法，主要用于处理分数、时间、答案等内容的格式化和转换

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class ExamUtil {

    public static String scoreToVM(Integer score) {
        if (score % 10 == 0) {
            return String.valueOf(score / 10);
        } else {
            return String.format("%.1f", score / 10.0);
        }
    }//将内部存储的分数（乘以10后的整数）转换为前端显示的格式

    public static Integer scoreFromVM(String score) {
        if (score == null) {
            return null;
        } else {
            return (int) (Float.parseFloat(score) * 10);
        }
    }//将前端显示的分数格式转换为内部存储的格式（乘以10后的整数）

    public static String secondToVM(Integer second) {
        String dateTimes;
        long days = second / (60 * 60 * 24);
        long hours = (second % (60 * 60 * 24)) / (60 * 60);
        long minutes = (second % (60 * 60)) / 60;
        long seconds = second % 60;
        if (days > 0) {
            dateTimes = days + "天 " + hours + "时 " + minutes + "分 " + seconds + "秒";
        } else if (hours > 0) {
            dateTimes = hours + "时 " + minutes + "分 " + seconds + "秒";
        } else if (minutes > 0) {
            dateTimes = minutes + "分 " + seconds + "秒";
        } else {
            dateTimes = seconds + " 秒";
        }
        return dateTimes;
    }//将秒数转换为更易读的时间格式（天、时、分、秒）

    private static final String ANSWER_SPLIT = ",";

    public static String contentToString(List<String> contentArray) {
        return contentArray.stream().sorted().collect(Collectors.joining(ANSWER_SPLIT));
    }//将答案内容列表转换为排序后的字符串，元素之间用逗号分隔

    public static List<String> contentToArray(String contentArray) {
        return Arrays.asList(contentArray.split(ANSWER_SPLIT));
    }  //将用逗号分隔的字符串转换为答案内容列表

    private static final String FORM_ANSWER_SPLIT = "_";

    public static Integer lastNum(String str) {
        Integer start = str.lastIndexOf(FORM_ANSWER_SPLIT);
        return Integer.parseInt(str.substring(start + 1));
    }//从一个字符串中提取最后一个下划线后的数字
}

package xzs.repository;

//扩展了针对   UserEventLog   实体的特定数据库操作方法。
// 它的主要功能包括：
// 通用数据库操作：继承自   BaseMapper   的增删改查方法。
// 按用户 ID 查询：根据用户 ID 查询用户事件日志。• 分页查询：提供分页查询功能。
// 按日期范围统计：统计特定日期范围内的用户事件日志数量

import xzs.domain.UserEventLog;
import xzs.domain.other.KeyValue;
import xzs.viewmodel.admin.user.UserEventPageRequestVM;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.Date;
import java.util.List;

@Mapper
public interface UserEventLogMapper extends BaseMapper<UserEventLog> {

    List<UserEventLog> getUserEventLogByUserId(Integer id);

    List<UserEventLog> page(UserEventPageRequestVM requestVM);

    List<KeyValue> selectCountByDate(@Param("startTime") Date startTime, @Param("endTime") Date endTime);
}

package xzs.controller;

import xzs.base.SystemCode;
import org.springframework.boot.autoconfigure.web.ErrorProperties;
import org.springframework.boot.autoconfigure.web.servlet.error.BasicErrorController;
import org.springframework.boot.web.servlet.error.DefaultErrorAttributes;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;
import java.util.HashMap;
import java.util.Map;

//Spring MVC控制器，
// 它继承自Spring Boot提供的   BasicErrorController   类，用于处理和返回错误信息。
// 这个控制器的作用是提供一个统一的错误处理机制，确保在发生错误时，用户能够得到清晰的反馈

@RestController
public class ErrorController extends BasicErrorController {

    private static final String PATH = "/error";

    public ErrorController() {
        super(new DefaultErrorAttributes(), new ErrorProperties());
    }

    @RequestMapping(produces = {MediaType.APPLICATION_JSON_VALUE})
    @ResponseBody
    public ResponseEntity<Map<String, Object>> error(HttpServletRequest request) {
        Map<String, Object> error = new HashMap<>(2);
        error.put("code", SystemCode.InnerError.getCode());
        error.put("message", SystemCode.InnerError.getMessage());
        return new ResponseEntity<>(error, HttpStatus.OK);
    }
    //处理错误请求的方法，
    // 它接收一个   HttpServletRequest   对象，从中获取错误信息，并构造一个包含错误代码和消息的Map对象
    @Override
    public String getErrorPath() {
        return PATH;
    }
}

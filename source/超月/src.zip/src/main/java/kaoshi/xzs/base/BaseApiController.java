package xzs.base;


import xzs.context.WebContext;
import xzs.domain.User;
import xzs.utility.ModelMapperSingle;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;

/*BaseApiController   类通过提供一些基础功能，如用户信息获取、对象映射和分页处理，
来简化 Spring Boot 应用中 API 控制器的开发。
它使得控制器能够更加专注于业务逻辑的实现，而不必关心一些通用的功能实现*/
public class BaseApiController {
    protected final static String DEFAULT_PAGE_SIZE = "10";
    //常量，用于定义默认的页面大小

    protected final static ModelMapper modelMapper = ModelMapperSingle.Instance();
    //这里通过 ModelMapperSingle.Instance()   获取单例实例，确保整个应用中   ModelMapper   的实例是唯一的

    @Autowired
    protected WebContext webContext;

    protected User getCurrentUser() {
        return webContext.getCurrentUser();
    }
    //返回当前登录的用户
}

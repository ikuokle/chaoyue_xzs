package xzs.repository;

//扩展了针对   MessageUser   实体的特定数据库操作方法。
// 它的主要功能包括：
// 通用数据库操作：继承自   BaseMapper   的增删改查方法。
// 批量查询：根据消息 ID 列表查询用户消息关联记录。
// 批量插入：支持批量插入用户消息关联记录。• 分页查询：提供学生端的分页查询功能。
// 未读消息统计：统计指定用户的未读消息数量

import xzs.domain.MessageUser;
import xzs.viewmodel.student.user.MessageRequestVM;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface MessageUserMapper extends BaseMapper<MessageUser> {

    List<MessageUser> selectByMessageIds(List<Integer> ids);

    int inserts(List<MessageUser> list);

    List<MessageUser> studentPage(MessageRequestVM requestVM);

    Integer unReadCount(Integer userId);
}

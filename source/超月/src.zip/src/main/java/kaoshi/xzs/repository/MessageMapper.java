package xzs.repository;

//扩展了针对   Message   实体的特定数据库操作方法。
// 它的主要功能包括：
// 通用数据库操作：继承自   BaseMapper   的增删改查方法。
// 分页查询：提供分页查询功能。
// 批量查询：根据 ID 列表查询消息。
// 标记为已读：更新消息的阅读状态。

import xzs.domain.Message;
import xzs.viewmodel.admin.message.MessagePageRequestVM;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface MessageMapper extends BaseMapper<Message> {

    List<Message> page(MessagePageRequestVM requestVM);

    List<Message> selectByIds(List<Integer> ids);

    int readAdd(Integer id);
}

package xzs.domain;

//学生对试卷的答题信息

import java.util.List;

public class ExamPaperAnswerInfo {
    public ExamPaper examPaper;// 试卷对象
    public ExamPaperAnswer examPaperAnswer;// 答题记录对象
    public List<ExamPaperQuestionCustomerAnswer> examPaperQuestionCustomerAnswers;// 题目答案列表

    public ExamPaper getExamPaper() {
        return examPaper;
    }

    public void setExamPaper(ExamPaper examPaper) {
        this.examPaper = examPaper;
    }

    public ExamPaperAnswer getExamPaperAnswer() {
        return examPaperAnswer;
    }

    public void setExamPaperAnswer(ExamPaperAnswer examPaperAnswer) {
        this.examPaperAnswer = examPaperAnswer;
    }

    public List<ExamPaperQuestionCustomerAnswer> getExamPaperQuestionCustomerAnswers() {
        return examPaperQuestionCustomerAnswers;
    }

    public void setExamPaperQuestionCustomerAnswers(List<ExamPaperQuestionCustomerAnswer> examPaperQuestionCustomerAnswers) {
        this.examPaperQuestionCustomerAnswers = examPaperQuestionCustomerAnswers;
    }
}

package xzs.controller.admin;


import xzs.base.BaseApiController;
import xzs.base.RestResponse;
import xzs.domain.TaskExam;
import xzs.service.TaskExamService;
import xzs.utility.DateTimeUtil;
import xzs.utility.PageInfoHelper;
import xzs.viewmodel.admin.task.TaskPageRequestVM;
import xzs.viewmodel.admin.task.TaskPageResponseVM;
import xzs.viewmodel.admin.task.TaskRequestVM;
import com.github.pagehelper.PageInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

//Spring MVC控制器，它负责处理与任务考试（Task Exam）相关的请求。
// 这个控制器扩展自   BaseApiController  ，
// 提供了管理任务考试的端点，包括列出任务、编辑任务、选择特定任务以及删除任务。
// 它通过依赖注入   TaskExamService   服务来执行任务考试相关的业务逻辑

@RestController("AdminTaskController")
@RequestMapping(value = "/api/admin/task")
public class TaskController extends BaseApiController {

    private final TaskExamService taskExamService;

    @Autowired
    public TaskController(TaskExamService taskExamService) {
        this.taskExamService = taskExamService;
    }

    @RequestMapping(value = "/page", method = RequestMethod.POST)
    public RestResponse<PageInfo<TaskPageResponseVM>> pageList(@RequestBody TaskPageRequestVM model) {
        PageInfo<TaskExam> pageInfo = taskExamService.page(model);
        PageInfo<TaskPageResponseVM> page = PageInfoHelper.copyMap(pageInfo, m -> {
            TaskPageResponseVM vm = modelMapper.map(m, TaskPageResponseVM.class);
            vm.setCreateTime(DateTimeUtil.dateFormat(m.getCreateTime()));
            return vm;
        });
        return RestResponse.ok(page);
    }//处理分页查询任务考试的请求


    @RequestMapping(value = "/edit", method = RequestMethod.POST)
    public RestResponse edit(@RequestBody @Valid TaskRequestVM model) {
        taskExamService.edit(model, getCurrentUser());
        TaskRequestVM vm = taskExamService.taskExamToVM(model.getId());
        return RestResponse.ok(vm);
    }//处理编辑任务考试的请求


    @RequestMapping(value = "/select/{id}", method = RequestMethod.POST)
    public RestResponse<TaskRequestVM> select(@PathVariable Integer id) {
        TaskRequestVM vm = taskExamService.taskExamToVM(id);
        return RestResponse.ok(vm);
    }//根据给定ID选择特定任务考试的请求

    @RequestMapping(value = "/delete/{id}", method = RequestMethod.POST)
    public RestResponse delete(@PathVariable Integer id) {
        TaskExam taskExam = taskExamService.selectById(id);
        taskExam.setDeleted(true);
        taskExamService.updateByIdFilter(taskExam);
        return RestResponse.ok();
    }//根据给定ID删除任务考试的请求
}

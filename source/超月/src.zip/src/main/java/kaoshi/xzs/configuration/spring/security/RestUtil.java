package xzs.configuration.spring.security;

import xzs.base.RestResponse;
import xzs.base.SystemCode;
import xzs.utility.JsonUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
//生成和发送 JSON 格式的 HTTP 响应

public class RestUtil {
    private static final Logger logger = LoggerFactory.getLogger(RestUtil.class);
    //记录日志信息

    public static void response(HttpServletResponse response, SystemCode systemCode) {
        response(response, systemCode.getCode(), systemCode.getMessage());
    }//发送包含预定义状态码和消息的响应

    public static void response(HttpServletResponse response, int systemCode, String msg) {
        response(response, systemCode, msg, null);
    }//发送状态码和消息的响应

    public static void response(HttpServletResponse response, int systemCode,
                                String msg, Object content) {
        try {
            RestResponse res = new RestResponse<>(systemCode, msg, content);
            String resStr = JsonUtil.toJsonStr(res);
            response.setContentType("application/json;charset=utf-8");
            response.getWriter().write(resStr);
        } catch (IOException e) {
            logger.error(e.getMessage(), e);
        }
    }//发送状态码、消息和响应体内容的响应
}

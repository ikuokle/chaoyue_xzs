package xzs.configuration.spring.security;

import xzs.base.SystemCode;
import xzs.domain.User;
import xzs.domain.UserEventLog;
import xzs.event.UserEvent;
import xzs.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.security.core.Authentication;
import org.springframework.security.web.authentication.logout.SimpleUrlLogoutSuccessHandler;
import org.springframework.stereotype.Component;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.Date;

//处理用户成功注销（登出）后的逻辑

@Component
public class RestLogoutSuccessHandler extends SimpleUrlLogoutSuccessHandler {

    private final ApplicationEventPublisher eventPublisher;
    private final UserService userService;

    @Autowired
    public RestLogoutSuccessHandler(ApplicationEventPublisher eventPublisher, UserService userService) {
        this.eventPublisher = eventPublisher;
        this.userService = userService;
    }

    @Override
    public void onLogoutSuccess(HttpServletRequest request, HttpServletResponse response, Authentication authentication) {
        org.springframework.security.core.userdetails.User springUser = (org.springframework.security.core.userdetails.User) authentication.getPrincipal();
        if (null != springUser) {
            User user = userService.getUserByUserName(springUser.getUsername());
            UserEventLog userEventLog = new UserEventLog(user.getId(), user.getUserName(), user.getRealName(), new Date());
            userEventLog.setContent(user.getUserName() + " 登出了超月小助手考试系统");
            eventPublisher.publishEvent(new UserEvent(userEventLog));
        }
        RestUtil.response(response, SystemCode.OK);
    }//用户成功注销后被调用
    /*1. 获取认证信息：从   Authentication   对象中获取用户信息。
    2. 查询用户详情：使用   UserService   通过用户名查询用户详细信息。
    3. 记录用户事件：创建一个   UserEventLog   对象，记录用户的注销事件，并通过   ApplicationEventPublisher   发布这个事件。
    4. 构建响应：如果用户存在，使用   RestUtil.response   方法发送一个包含成功信息的响应给客户端。*/
}

package xzs.controller.student;

import xzs.base.BaseApiController;
import xzs.base.RestResponse;
import xzs.domain.TaskExam;
import xzs.domain.TaskExamCustomerAnswer;
import xzs.domain.TextContent;
import xzs.domain.User;
import xzs.domain.enums.ExamPaperTypeEnum;
import xzs.domain.task.TaskItemAnswerObject;
import xzs.domain.task.TaskItemObject;
import xzs.service.*;
import xzs.utility.DateTimeUtil;
import xzs.utility.JsonUtil;
import xzs.viewmodel.student.dashboard.*;
import xzs.service.*;
import xzs.viewmodel.student.dashboard.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

@RestController("StudentDashboardController")
//标识该类是一个控制器，其所有方法的返回值都将自动转换为 JSON 格式的 HTTP 响应体
@RequestMapping(value = "/api/student/dashboard")
//定义了类级别的请求映射，所有该控制器的方法都将在   /api/student/dashboard   路径下

public class DashboardController extends BaseApiController {

    private final UserService userService;//操作用户信息的服务
    private final ExamPaperService examPaperService;//操作考试试卷的服务
    private final QuestionService questionService;//操作问题的的服务
    private final TaskExamService taskExamService;//操作任务考试的服务
    private final TaskExamCustomerAnswerService taskExamCustomerAnswerService;
    //操作任务考试客户答案的服务
    private final TextContentService textContentService;//操作文本内容的服务

    @Autowired
    public DashboardController(UserService userService,
           ExamPaperService examPaperService, QuestionService questionService,
            TaskExamService taskExamService,
            TaskExamCustomerAnswerService taskExamCustomerAnswerService,
            TextContentService textContentService) {
        this.userService = userService;
        this.examPaperService = examPaperService;
        this.questionService = questionService;
        this.taskExamService = taskExamService;
        this.taskExamCustomerAnswerService = taskExamCustomerAnswerService;
        this.textContentService = textContentService;
    }

    @RequestMapping(value = "/index", method = RequestMethod.POST)
    public RestResponse<IndexVM> index() {
        IndexVM indexVM = new IndexVM();
        User user = getCurrentUser();

        PaperFilter fixedPaperFilter = new PaperFilter();
        fixedPaperFilter.setGradeLevel(user.getUserLevel());
        fixedPaperFilter.setExamPaperType(ExamPaperTypeEnum.Fixed.getCode());
        indexVM.setFixedPaper(examPaperService.indexPaper(fixedPaperFilter));

        PaperFilter timeLimitPaperFilter = new PaperFilter();
        timeLimitPaperFilter.setDateTime(new Date());
        timeLimitPaperFilter.setGradeLevel(user.getUserLevel());
        timeLimitPaperFilter.setExamPaperType(ExamPaperTypeEnum.TimeLimit.getCode());

        List<PaperInfo> limitPaper = examPaperService.indexPaper(timeLimitPaperFilter);
        List<PaperInfoVM> paperInfoVMS = limitPaper.stream().map(d -> {
            PaperInfoVM vm = modelMapper.map(d, PaperInfoVM.class);
            vm.setStartTime(DateTimeUtil.dateFormat(d.getLimitStartTime()));
            vm.setEndTime(DateTimeUtil.dateFormat(d.getLimitEndTime()));
            return vm;
        }).collect(Collectors.toList());
        indexVM.setTimeLimitPaper(paperInfoVMS);
        return RestResponse.ok(indexVM);
    }/*构建并返回一个   IndexVM  （视图模型），包含以下信息：
    • 固定试卷列表（  fixedPaper  ）：根据学生的年级和试卷类型获取的固定试卷列表。
    • 时间限制试卷列表（  timeLimitPaper  ）：根据当前时间和学生的年级获取的时间限制试卷列表，并转换为   PaperInfoVM   对象列表。*/


    @RequestMapping(value = "/task", method = RequestMethod.POST)
    public RestResponse<List<TaskItemVm>> task() {
        User user = getCurrentUser();
        List<TaskExam> taskExams = taskExamService.getByGradeLevel(user.getUserLevel());
        if (taskExams.size() == 0) {
            return RestResponse.ok(new ArrayList<>());
        }
        List<Integer> tIds = taskExams.stream().map(taskExam -> taskExam.getId()).collect(Collectors.toList());
        List<TaskExamCustomerAnswer> taskExamCustomerAnswers = taskExamCustomerAnswerService.selectByTUid(tIds, user.getId());
        List<TaskItemVm> vm = taskExams.stream().map(t -> {
            TaskItemVm itemVm = new TaskItemVm();
            itemVm.setId(t.getId());
            itemVm.setTitle(t.getTitle());
            TaskExamCustomerAnswer taskExamCustomerAnswer = taskExamCustomerAnswers.stream()
                    .filter(tc -> tc.getTaskExamId().equals(t.getId())).findFirst().orElse(null);
            List<TaskItemPaperVm> paperItemVMS = getTaskItemPaperVm(t.getFrameTextContentId(), taskExamCustomerAnswer);
            itemVm.setPaperItems(paperItemVMS);
            return itemVm;
        }).collect(Collectors.toList());
        return RestResponse.ok(vm);
    }/*获取当前登录学生的任务考试信息，并构建   TaskItemVm   列表，包含以下信息：
    • 任务考试列表（  taskExams  ）：根据学生年级获取的任务考试列表。
    • 任务考试客户答案列表（  taskExamCustomerAnswers  ）：根据任务考试ID和学生ID获取的任务考试客户答案列表。
    • 试卷项列表（  paperItems  ）：根据任务考试的框架文本内容ID和任务考试客户答案获取的试卷项列表。*/


    private List<TaskItemPaperVm> getTaskItemPaperVm(Integer tFrameId,
                                                     TaskExamCustomerAnswer taskExamCustomerAnswers) {
        TextContent textContent = textContentService.selectById(tFrameId);
        List<TaskItemObject> paperItems = JsonUtil.toJsonListObject(textContent.getContent(),
                TaskItemObject.class);

        List<TaskItemAnswerObject> answerPaperItems = null;
        if (null != taskExamCustomerAnswers) {
            TextContent answerTextContent = textContentService.selectById(taskExamCustomerAnswers.
                    getTextContentId());
            answerPaperItems = JsonUtil.toJsonListObject(answerTextContent.getContent(),
                    TaskItemAnswerObject.class);
        }


        List<TaskItemAnswerObject> finalAnswerPaperItems = answerPaperItems;
        return paperItems.stream().map(p -> {
                    TaskItemPaperVm ivm = new TaskItemPaperVm();
                    ivm.setExamPaperId(p.getExamPaperId());
                    ivm.setExamPaperName(p.getExamPaperName());
                    if (null != finalAnswerPaperItems) {
                        finalAnswerPaperItems.stream()
                                .filter(a -> a.getExamPaperId().equals(p.getExamPaperId()))
                                .findFirst()
                                .ifPresent(a -> {
                                    ivm.setExamPaperAnswerId(a.getExamPaperAnswerId());
                                    ivm.setStatus(a.getStatus());
                                });
                    }
                    return ivm;
                }
        ).collect(Collectors.toList());
    }/*它的作用是将任务考试（TaskExam）中的试卷项（  TaskItemObject  ）转换为视图模型（ViewModel），以便在前端展示。
    这个方法处理了从服务层获取的数据，并将其转换为适合前端使用的格式。*/
}

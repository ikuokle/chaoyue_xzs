package xzs.domain.exam;

//表示试卷中的题目项。
// 它主要包含两个属性：题目ID和题目顺序

public class ExamPaperQuestionItemObject {
    private Integer id;
    private Integer itemOrder;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getItemOrder() {
        return itemOrder;
    }

    public void setItemOrder(Integer itemOrder) {
        this.itemOrder = itemOrder;
    }
}

package xzs.base;

/*BasePage   类是一个基础的分页实体类，它通过提供页码和每页大小的属性，
为实现分页功能提供了便利。这个类可以被扩展或直接使用在需要分页逻辑的应用中，
以帮助开发者管理和限制数据的检索和展示。*/
public class BasePage {

    private Integer pageIndex;
    //存储当前页码
    private Integer pageSize;
    //存储每页显示的记录数

    public Integer getPageIndex() {
        return pageIndex;
    }
    //返回每页显示的记录数

    public void setPageIndex(Integer pageIndex) {
        this.pageIndex = pageIndex;
    }
    //设置当前页码

    public Integer getPageSize() {
        return pageSize;
    }
    //返回每页显示的记录数

    public void setPageSize(Integer pageSize) {
        this.pageSize = pageSize;
    }
    //设置每页显示的记录数
}

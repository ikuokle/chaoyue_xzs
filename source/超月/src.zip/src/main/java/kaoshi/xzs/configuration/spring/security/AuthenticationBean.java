package xzs.configuration.spring.security;

//处理用户的身份验证请求
public class AuthenticationBean {
    private String userName;//用户名
    private String password;//密码
    private boolean remember;//存储用户是否选择了“记住我”功能

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public boolean isRemember() {
        return remember;
    }

    public void setRemember(boolean remember) {
        this.remember = remember;
    }

}

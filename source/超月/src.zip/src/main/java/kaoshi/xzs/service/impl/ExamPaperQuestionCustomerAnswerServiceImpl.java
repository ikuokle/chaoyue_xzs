package xzs.service.impl;

import xzs.domain.ExamPaperQuestionCustomerAnswer;
import xzs.domain.other.ExamPaperAnswerUpdate;
import xzs.domain.other.KeyValue;
import xzs.domain.TextContent;
import xzs.domain.enums.QuestionTypeEnum;
import xzs.repository.ExamPaperQuestionCustomerAnswerMapper;
import xzs.service.ExamPaperQuestionCustomerAnswerService;
import xzs.service.TextContentService;
import xzs.utility.DateTimeUtil;
import xzs.utility.ExamUtil;
import xzs.utility.JsonUtil;
import xzs.viewmodel.student.exam.ExamPaperSubmitItemVM;
import xzs.viewmodel.student.question.answer.QuestionPageStudentRequestVM;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

//提供了考试试卷题目客户答案（即学生答案）相关的业务逻辑
//使用了   ExamPaperQuestionCustomerAnswerMapper   来执行数据库操作，
// 以及   TextContentService   来处理文本内容

@Service
public class ExamPaperQuestionCustomerAnswerServiceImpl extends BaseServiceImpl<ExamPaperQuestionCustomerAnswer> implements ExamPaperQuestionCustomerAnswerService {

    private final ExamPaperQuestionCustomerAnswerMapper examPaperQuestionCustomerAnswerMapper;
    private final TextContentService textContentService;

    @Autowired
    public ExamPaperQuestionCustomerAnswerServiceImpl(ExamPaperQuestionCustomerAnswerMapper examPaperQuestionCustomerAnswerMapper, TextContentService textContentService) {
        super(examPaperQuestionCustomerAnswerMapper);
        this.examPaperQuestionCustomerAnswerMapper = examPaperQuestionCustomerAnswerMapper;
        this.textContentService = textContentService;
    }


    @Override
    public PageInfo<ExamPaperQuestionCustomerAnswer> studentPage(QuestionPageStudentRequestVM requestVM) {
        return PageHelper.startPage(requestVM.getPageIndex(), requestVM.getPageSize(), "id desc").doSelectPageInfo(() ->
                examPaperQuestionCustomerAnswerMapper.studentPage(requestVM)
        );
    }//根据学生请求的分页信息，查询并返回分页结果

    @Override
    public List<ExamPaperQuestionCustomerAnswer> selectListByPaperAnswerId(Integer id) {
        return examPaperQuestionCustomerAnswerMapper.selectListByPaperAnswerId(id);
    }//根据试卷答案ID查询相关的题目答案列表


    @Override
    public void insertList(List<ExamPaperQuestionCustomerAnswer> examPaperQuestionCustomerAnswers) {
        examPaperQuestionCustomerAnswerMapper.insertList(examPaperQuestionCustomerAnswers);
    }//批量插入题目答案

    @Override
    public ExamPaperSubmitItemVM examPaperQuestionCustomerAnswerToVM(ExamPaperQuestionCustomerAnswer qa) {
        ExamPaperSubmitItemVM examPaperSubmitItemVM = new ExamPaperSubmitItemVM();
        examPaperSubmitItemVM.setId(qa.getId());
        examPaperSubmitItemVM.setQuestionId(qa.getQuestionId());
        examPaperSubmitItemVM.setDoRight(qa.getDoRight());
        examPaperSubmitItemVM.setItemOrder(qa.getItemOrder());
        examPaperSubmitItemVM.setQuestionScore(ExamUtil.scoreToVM(qa.getQuestionScore()));
        examPaperSubmitItemVM.setScore(ExamUtil.scoreToVM(qa.getCustomerScore()));
        setSpecialToVM(examPaperSubmitItemVM, qa);
        return examPaperSubmitItemVM;
    }//将题目答案转换为视图模型（ViewModel）

    @Override
    public Integer selectAllCount() {
        return examPaperQuestionCustomerAnswerMapper.selectAllCount();
    }//查询所有题目答案的总数

    @Override
    public List<Integer> selectMothCount() {
        Date startTime = DateTimeUtil.getMonthStartDay();
        Date endTime = DateTimeUtil.getMonthEndDay();
        List<KeyValue> mouthCount = examPaperQuestionCustomerAnswerMapper.selectCountByDate(startTime, endTime);
        List<String> mothStartToNowFormat = DateTimeUtil.MothStartToNowFormat();
        return mothStartToNowFormat.stream().map(md -> {
            KeyValue keyValue = mouthCount.stream().filter(kv -> kv.getName().equals(md)).findAny().orElse(null);
            return null == keyValue ? 0 : keyValue.getValue();
        }).collect(Collectors.toList());
    }//查询每月题目答案的数量

    @Override
    public int updateScore(List<ExamPaperAnswerUpdate> examPaperAnswerUpdates) {
        return examPaperQuestionCustomerAnswerMapper.updateScore(examPaperAnswerUpdates);
    }//更新题目答案的分数

    private void setSpecialToVM(ExamPaperSubmitItemVM examPaperSubmitItemVM,//视图模型对象，用于展示学生提交的题目答案
                                ExamPaperQuestionCustomerAnswer examPaperQuestionCustomerAnswer//学生提交的题目答案对象
    ) {
        QuestionTypeEnum questionTypeEnum = QuestionTypeEnum.fromCode(examPaperQuestionCustomerAnswer.getQuestionType());
        //从  examPaperQuestionCustomerAnswer  对象中获取题目类型代码，
        //并通过  QuestionTypeEnum.fromCode  方法将其转换为枚举类型  QuestionTypeEnum
        switch (questionTypeEnum) {
            case MultipleChoice:
                examPaperSubmitItemVM.setContent(examPaperQuestionCustomerAnswer.getAnswer());
                //设置答案内容：将学生提交的多选题答案（  examPaperQuestionCustomerAnswer.getAnswer()  ）设置到视图模型的  content  属性中

                examPaperSubmitItemVM.setContentArray(ExamUtil.contentToArray(examPaperQuestionCustomerAnswer.getAnswer()));
                //使用  ExamUtil.contentToArray  方法将答案字符串转换为数组，并将结果设置到视图模型的  contentArray  属性中

                break;
                case GapFilling:
                TextContent textContent = textContentService.selectById(examPaperQuestionCustomerAnswer.getTextContentId());
                //通过  textContentService.selectById  方法，根据  examPaperQuestionCustomerAnswer.getTextContentId()  获取对应的  TextContent  对象

                List<String> correctAnswer = JsonUtil.toJsonListObject(textContent.getContent(), String.class);
                //使用  JsonUtil.toJsonListObject  方法将  TextContent  对象中的内容（通常是JSON格式的字符串）解析为一个字符串列表  correctAnswer

                examPaperSubmitItemVM.setContentArray(correctAnswer);
                //将解析后的正确答案列表设置到视图模型的  contentArray  属性中
                break;

            default:
                if (QuestionTypeEnum.needSaveTextContent(examPaperQuestionCustomerAnswer.getQuestionType())) {
                    TextContent content = textContentService.selectById(examPaperQuestionCustomerAnswer.getTextContentId());
                    examPaperSubmitItemVM.setContent(content.getContent());
                    //如果需要保存文本内容，通过  textContentService.selectById  方法获取  TextContent  对象，
                    //并将其内容设置到视图模型的  content  属性中
                } else {
                    examPaperSubmitItemVM.setContent(examPaperQuestionCustomerAnswer.getAnswer());
                    //如果不需要保存文本内容，直接将学生提交的答案（  examPaperQuestionCustomerAnswer.getAnswer()  ）
                    // 设置到视图模型的  content  属性中
                }
                break;
        }
    }//据题目类型设置视图模型的特定内容
}

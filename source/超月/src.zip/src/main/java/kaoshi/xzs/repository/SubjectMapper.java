package xzs.repository;

//针对   Subject   实体的特定数据库操作方法。
// 它的主要功能包括：
// 通用数据库操作：继承自   BaseMapper   的增删改查方法。
// 按级别查询：根据学科级别查询学科列表。
// 查询所有学科：获取所有学科的列表。
// 分页查询：提供分页查询功能。

import xzs.domain.Subject;
import xzs.viewmodel.admin.education.SubjectPageRequestVM;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface SubjectMapper  extends BaseMapper<Subject> {

    List<Subject> getSubjectByLevel(Integer level);

    List<Subject> allSubject();

    List<Subject> page(SubjectPageRequestVM requestVM);
}

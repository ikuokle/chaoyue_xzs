package xzs.configuration.spring.security;

import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.web.authentication.rememberme.TokenBasedRememberMeServices;

import javax.servlet.http.HttpServletRequest;

//用于实现“记住我”功能

public class RestTokenBasedRememberMeServices extends TokenBasedRememberMeServices {

    public RestTokenBasedRememberMeServices(String key, UserDetailsService userDetailsService) {
        super(key, userDetailsService);
    }//生成令牌的密钥  key  ，加载用户信息的   UserDetailsService

    @Override
    protected boolean rememberMeRequested(HttpServletRequest request, String parameter) {
        return (boolean) request.getAttribute(DEFAULT_PARAMETER);
    }//用于检查用户是否请求了“记住我”功能

}

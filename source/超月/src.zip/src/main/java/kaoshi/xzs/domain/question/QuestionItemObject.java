package xzs.domain.question;

//表示一个题目的详细信息

public class QuestionItemObject {

    private String prefix;//题目的前缀或标识符

    private String content;//题目的具体内容

    private Integer score;//题目的分数

    private String itemUuid;//题目的唯一标识符（UUID

    public String getPrefix() {
        return prefix;
    }

    public void setPrefix(String prefix) {
        this.prefix = prefix;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public Integer getScore() {
        return score;
    }

    public void setScore(Integer score) {
        this.score = score;
    }

    public String getItemUuid() {
        return itemUuid;
    }

    public void setItemUuid(String itemUuid) {
        this.itemUuid = itemUuid;
    }
}

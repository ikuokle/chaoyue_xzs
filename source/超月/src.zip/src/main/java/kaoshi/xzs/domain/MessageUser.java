package xzs.domain;

//一条消息与接收者之间的关系

import java.io.Serializable;
import java.util.Date;

public class MessageUser implements Serializable {
    private Integer id;// 消息用户关系ID

    private Integer messageId;//消息内容ID

    private Integer receiveUserId;// 接收人ID

    private String receiveUserName;// 接收人用户名

    private String receiveRealName;// 接收人真实姓名

    private Boolean readed;// 是否已读

    private Date createTime;// 创建时间

    private Date readTime; // 阅读时间

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getMessageId() {
        return messageId;
    }

    public void setMessageId(Integer messageId) {
        this.messageId = messageId;
    }

    public Integer getReceiveUserId() {
        return receiveUserId;
    }

    public void setReceiveUserId(Integer receiveUserId) {
        this.receiveUserId = receiveUserId;
    }

    public String getReceiveUserName() {
        return receiveUserName;
    }

    public void setReceiveUserName(String receiveUserName) {
        this.receiveUserName = receiveUserName == null ? null : receiveUserName.trim();
    }

    public String getReceiveRealName() {
        return receiveRealName;
    }

    public void setReceiveRealName(String receiveRealName) {
        this.receiveRealName = receiveRealName == null ? null : receiveRealName.trim();
    }

    public Boolean getReaded() {
        return readed;
    }

    public void setReaded(Boolean readed) {
        this.readed = readed;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Date getReadTime() {
        return readTime;
    }

    public void setReadTime(Date readTime) {
        this.readTime = readTime;
    }
}

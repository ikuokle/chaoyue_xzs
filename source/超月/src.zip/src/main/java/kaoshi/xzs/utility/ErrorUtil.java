package xzs.utility;

public class ErrorUtil {

    public static String parameterErrorFormat(String field, String msg) {
        return "【" + field + " : " + msg + "】";
    }//格式化参数错误信息
}

package xzs.service.impl;

//实现了   MessageService   接口的服务类，专门处理与消息相关的业务逻辑。
// 它的主要功能包括：
// 1. 消息查询：根据消息 ID 列表查询消息。
// 2. 分页查询：提供学生端和管理员端的分页查询功能。
// 3. 发送消息：发送消息并记录消息的接收者。
// 4. 标记为已读：将消息标记为已读，并更新相关记录。
// 5. 未读消息统计：统计指定用户的未读消息数量。
// 6. 消息详情查询：根据消息用户 ID 查询消息详情

import xzs.domain.Message;
import xzs.domain.MessageUser;
import xzs.repository.MessageMapper;
import xzs.repository.MessageUserMapper;
import xzs.service.MessageService;
import xzs.viewmodel.admin.message.MessagePageRequestVM;
import xzs.viewmodel.student.user.MessageRequestVM;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Date;
import java.util.List;

@Service
public class MessageServiceImpl implements MessageService {

    private final MessageMapper messageMapper;//用于操作消息的数据库表
    private final MessageUserMapper messageUserMapper;//用于操作用户消息关联的数据库表

    @Autowired
    public MessageServiceImpl(MessageMapper messageMapper, MessageUserMapper messageUserMapper) {
        this.messageMapper = messageMapper;
        this.messageUserMapper = messageUserMapper;
    }

    @Override
    public List<Message> selectMessageByIds(List<Integer> ids) {
        return messageMapper.selectByIds(ids);
    }//根据消息 ID 列表查询消息

    @Override
    public PageInfo<MessageUser> studentPage(MessageRequestVM requestVM) {
        return PageHelper.startPage(requestVM.getPageIndex(), requestVM.getPageSize(), "id desc").doSelectPageInfo(() ->
                messageUserMapper.studentPage(requestVM)
        );
    }//根据学生端的分页请求查询用户消息关联记录

    @Override
    public PageInfo<Message> page(MessagePageRequestVM requestVM) {
        return PageHelper.startPage(requestVM.getPageIndex(), requestVM.getPageSize(), "id desc").doSelectPageInfo(() ->
                messageMapper.page(requestVM)
        );
    }//根据管理员端的分页请求查询消息列表

    @Override
    public List<MessageUser> selectByMessageIds(List<Integer> ids) {
        return messageUserMapper.selectByMessageIds(ids);
    }//根据消息 ID 列表查询用户消息关联记录

    @Override
    @Transactional
    public void sendMessage(Message message, List<MessageUser> messageUsers) {
        messageMapper.insertSelective(message);
        messageUsers.forEach(d -> d.setMessageId(message.getId()));
        messageUserMapper.inserts(messageUsers);
    }//发送消息并记录消息的接收者

    @Override
    @Transactional
    public void read(Integer id) {
        MessageUser messageUser = messageUserMapper.selectByPrimaryKey(id);
        if (messageUser.getReaded())
            return;
        messageUser.setReaded(true);
        messageUser.setReadTime(new Date());
        messageUserMapper.updateByPrimaryKeySelective(messageUser);
        messageMapper.readAdd(messageUser.getMessageId());
    }//将消息标记为已读，并更新相关记录

    @Override
    public Integer unReadCount(Integer userId) {
        return messageUserMapper.unReadCount(userId);
    }//统计指定用户的未读消息数量

    @Override
    public Message messageDetail(Integer id) {
        MessageUser messageUser = messageUserMapper.selectByPrimaryKey(id);
        return messageMapper.selectByPrimaryKey(messageUser.getMessageId());
    }//根据消息用户 ID 查询消息详情

}

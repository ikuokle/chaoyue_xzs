package xzs.configuration.spring.security;

import xzs.base.SystemCode;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.web.authentication.LoginUrlAuthenticationEntryPoint;
import org.springframework.stereotype.Component;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
//在用户未认证（即未登录）时访问受保护资源，强制重定向到登录页面或返回一个错误响应

@Component
public final class LoginAuthenticationEntryPoint extends LoginUrlAuthenticationEntryPoint {

    public LoginAuthenticationEntryPoint() {
        super("/api/user/login");
    }
    //调用了父类的构造函数，当用户尝试访问一个需要认证的资源而没有提供有效认证信息时，Spring Security 会重定向用户到这个 URL
    @Override
    public void commence(HttpServletRequest request, HttpServletResponse response,
                         AuthenticationException authException) throws IOException, ServletException {
        RestUtil.response(response, SystemCode.UNAUTHORIZED);//用于生成一个 HTTP 响应
    }//在用户未通过认证时，向客户端发送一个适当的错误响应

}

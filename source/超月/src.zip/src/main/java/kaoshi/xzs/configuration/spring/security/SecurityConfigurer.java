package xzs.configuration.spring.security;

import xzs.configuration.property.CookieConfig;
import xzs.configuration.property.SystemConfig;
import xzs.domain.enums.RoleEnum;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.CorsConfigurationSource;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;

import java.util.Collections;
import java.util.List;

//设置安全性约束

@Configuration   //标识这是一个配置类
@EnableWebSecurity  //启用 Spring Security 的 Web 安全支持
public class SecurityConfigurer {

    @Configuration
    public static class FormLoginWebSecurityConfigurerAdapter extends WebSecurityConfigurerAdapter {
    //配置表单登录的安全性

        private final SystemConfig systemConfig;//系统配置类
        private final LoginAuthenticationEntryPoint restAuthenticationEntryPoint;//认证入口点
        private final RestAuthenticationProvider restAuthenticationProvider;//认证提供者
        private final RestDetailsServiceImpl formDetailsService;//加载用户信息
        private final RestAuthenticationSuccessHandler restAuthenticationSuccessHandler;//认证成功处理器
        private final RestAuthenticationFailureHandler restAuthenticationFailureHandler;//认证失败处理器
        private final RestLogoutSuccessHandler restLogoutSuccessHandler;//注销成功处理器
        private final RestAccessDeniedHandler restAccessDeniedHandler;//访问拒绝处理器


        @Autowired
        public FormLoginWebSecurityConfigurerAdapter(SystemConfig systemConfig,
                                                     LoginAuthenticationEntryPoint restAuthenticationEntryPoint,
                                                     RestAuthenticationProvider restAuthenticationProvider,
                                                     RestDetailsServiceImpl formDetailsService,
                                                     RestAuthenticationSuccessHandler restAuthenticationSuccessHandler,
                                                     RestAuthenticationFailureHandler restAuthenticationFailureHandler,
                                                     RestLogoutSuccessHandler restLogoutSuccessHandler,
                                                     RestAccessDeniedHandler restAccessDeniedHandler) {
            this.systemConfig = systemConfig;
            this.restAuthenticationEntryPoint = restAuthenticationEntryPoint;
            this.restAuthenticationProvider = restAuthenticationProvider;
            this.formDetailsService = formDetailsService;
            this.restAuthenticationSuccessHandler = restAuthenticationSuccessHandler;
            this.restAuthenticationFailureHandler = restAuthenticationFailureHandler;
            this.restLogoutSuccessHandler = restLogoutSuccessHandler;
            this.restAccessDeniedHandler = restAccessDeniedHandler;
        }

        @Override
        protected void configure(HttpSecurity http) throws Exception {
            http.headers().frameOptions().disable();

            List<String> securityIgnoreUrls = systemConfig.getSecurityIgnoreUrls();
            String[] ignores = new String[securityIgnoreUrls.size()];
            http
                    .addFilterAt(authenticationFilter(), UsernamePasswordAuthenticationFilter.class)
                    .exceptionHandling().authenticationEntryPoint(restAuthenticationEntryPoint)
                    .and().authenticationProvider(restAuthenticationProvider)
                    .authorizeRequests()
                    .antMatchers(securityIgnoreUrls.toArray(ignores)).permitAll()
                    .antMatchers("/api/admin/**").hasRole(RoleEnum.ADMIN.getName())
                    .antMatchers("/api/student/**").hasRole(RoleEnum.STUDENT.getName())
                    .anyRequest().permitAll()
                    .and().exceptionHandling().accessDeniedHandler(restAccessDeniedHandler)
                    .and().formLogin().successHandler(restAuthenticationSuccessHandler).failureHandler(restAuthenticationFailureHandler)
                    .and().logout().logoutUrl("/api/user/logout").logoutSuccessHandler(restLogoutSuccessHandler).invalidateHttpSession(true)
                    .and().rememberMe().key(CookieConfig.getName()).tokenValiditySeconds(CookieConfig.getInterval()).userDetailsService(formDetailsService)
                    .and().csrf().disable()
                    .cors();
        }//配置 HTTP 安全性设置

        @Bean
        public CorsConfigurationSource corsConfigurationSource() {
            final CorsConfiguration configuration = new CorsConfiguration();
            configuration.setMaxAge(3600L);
            configuration.setAllowedOrigins(Collections.singletonList("*"));
            configuration.setAllowedMethods(Collections.singletonList("*"));
            configuration.setAllowCredentials(true);
            configuration.setAllowedHeaders(Collections.singletonList("*"));
            final UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
            source.registerCorsConfiguration("/api/**", configuration);
            return source;
        }//创建并返回一个   CorsConfigurationSource   Bean，用于定义 CORS 配置

        @Bean
        public RestLoginAuthenticationFilter authenticationFilter() throws Exception {
            RestLoginAuthenticationFilter authenticationFilter = new RestLoginAuthenticationFilter();
            authenticationFilter.setAuthenticationSuccessHandler(restAuthenticationSuccessHandler);
            authenticationFilter.setAuthenticationFailureHandler(restAuthenticationFailureHandler);
            authenticationFilter.setAuthenticationManager(authenticationManagerBean());
            authenticationFilter.setUserDetailsService(formDetailsService);
            return authenticationFilter;
        }//创建并返回一个   RestLoginAuthenticationFilter   Bean，用于处理 REST 风格的登录认证

    }
}

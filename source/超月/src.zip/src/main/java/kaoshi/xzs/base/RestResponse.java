package xzs.base;

/* RestResponse   是一个泛型类，用于封装 RESTful API 的响应数据。
它包含了状态码（  code  ）、消息（  message  ）以及响应体（  response  ），
其中   response   可以是任何类型的对象。*/
public class RestResponse<T> {
    private int code;// 表示响应的状态码
    private String message;//表示响应的消息
    private T response;//携带实际的响应数据

    public RestResponse(int code, String message) {
        this.code = code;
        this.message = message;
    }//构造一个只有状态码和消息的响应对象，用于表示错误或状态信息

    public RestResponse(int code, String message, T response) {
        this.code = code;
        this.message = message;
        this.response = response;
    }//构造一个包含状态码、消息和响应体的完整响应对象，用于表示成功的请求结果


    public static RestResponse fail(Integer code, String msg) {
        return new RestResponse<>(code, msg);
    }//创建一个表示失败的响应对象

    public static RestResponse ok() {
        SystemCode systemCode = SystemCode.OK;
        return new RestResponse<>(systemCode.getCode(), systemCode.getMessage());
    }//创建一个表示成功的响应对象

    public static <F> RestResponse<F> ok(F response) {
        SystemCode systemCode = SystemCode.OK;
        return new RestResponse<>(systemCode.getCode(), systemCode.getMessage(), response);
    }//创建一个包含成功状态和实际响应数据的响应对象

    public int getCode() {
        return code;
    }
    //获取响应的状态码
    public void setCode(int code) {
        this.code = code;
    }
    //设置响应的状态码
    public String getMessage() {
        return message;
    }
    //获取响应的消息
    public void setMessage(String message) {
        this.message = message;
    }
    //设置响应的消息
    public T getResponse() {
        return response;
    }
    //获取响应体
    public void setResponse(T response) {
        this.response = response;
    }
    //设置响应体
}

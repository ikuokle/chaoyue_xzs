package xzs.repository;

//扩展了针对   ExamPaperQuestionCustomerAnswer   实体的特定数据库操作方法。
// 它的主要功能包括：• 通用数据库操作：继承自   BaseMapper   的增删改查方法。
// 分页查询：提供学生端的分页查询功能。
// 批量插入：支持批量插入答题记录。
// 统计查询：按日期范围统计答题记录的数量。
// 特定记录查询：根据试卷答题 ID 查询答题记录。
// 批量更新分数：支持批量更新答题记录的分数。

import xzs.domain.ExamPaperQuestionCustomerAnswer;
import xzs.domain.other.ExamPaperAnswerUpdate;
import xzs.domain.other.KeyValue;
import xzs.viewmodel.student.question.answer.QuestionPageStudentRequestVM;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.Date;
import java.util.List;

@Mapper
public interface ExamPaperQuestionCustomerAnswerMapper extends BaseMapper<ExamPaperQuestionCustomerAnswer> {

    List<ExamPaperQuestionCustomerAnswer> selectListByPaperAnswerId(Integer id);

    List<ExamPaperQuestionCustomerAnswer> studentPage(QuestionPageStudentRequestVM requestVM);

    int insertList(List<ExamPaperQuestionCustomerAnswer> list);

    Integer selectAllCount();

    List<KeyValue> selectCountByDate(@Param("startTime") Date startTime, @Param("endTime") Date endTime);

    int updateScore(List<ExamPaperAnswerUpdate> examPaperAnswerUpdates);
}

package xzs.event;

//封装用户事件日志的信息，并通过事件机制通知其他组件进行后续处理

import xzs.domain.UserEventLog;
import org.springframework.context.ApplicationEvent;


public class UserEvent extends ApplicationEvent {

    private final UserEventLog userEventLog;
    //封装用户事件的详细信息，包括用户ID、用户名、真实姓名、事件内容和事件时间等

    public UserEvent(final UserEventLog userEventLog) {
        super(userEventLog);
        this.userEventLog = userEventLog;
    }

    public UserEventLog getUserEventLog() {
        return userEventLog;
    }
}

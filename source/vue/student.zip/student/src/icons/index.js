import Vue from 'vue'
import SvgIcon from '@/components/SvgIcon'// svg组件

// 全局注册SVG图标组件并导入文件
Vue.component('svg-icon', SvgIcon)

// 动态加载SVG组件，参数：SVG文件所在目录，是否搜索子目录，目标文件
const req = require.context('./svg', false, /\.svg$/)
const requireAll = requireContext => requireContext.keys().map(requireContext)
requireAll(req)

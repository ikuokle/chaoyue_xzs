import Cookies from 'js-cookie'
import userApi from '@/api/user'
// initial state
const state = {
  userName: Cookies.get('studentUserName'),
  userInfo: Cookies.get('studentUserInfo'),
  imagePath: Cookies.get('studentImagePath'),
  messageCount: 0
}

// 用户信息管理模块，记录登陆状态，用户信息以及消息
const actions = {
  initUserInfo ({ commit }) {
    userApi.getCurrentUser().then(re => {
      commit('setUserInfo', re.response)
    })
  },
  getUserMessageInfo ({ commit }) {
    userApi.getMessageCount().then(re => {
      commit('setMessageCount', re.response)
    })
  }
}

// 变更，同步操作
const mutations = {
  setUserName (state, userName) {
    state.userName = userName
    Cookies.set('studentUserName', userName, { expires: 30 })
  },
  setUserInfo: (state, userInfo) => {
    state.userInfo = userInfo
    Cookies.set('studentUserInfo', userInfo, { expires: 30 })
  },
  setImagePath: (state, imagePath) => {
    state.imagePath = imagePath
    Cookies.set('studentImagePath', imagePath, { expires: 30 })
  },
  setMessageCount: (state, messageCount) => {
    state.messageCount = messageCount
  },
  messageCountSubtract: (state, num) => {
    state.messageCount = state.messageCount - num
  },
  // 清理登录状态
  clearLogin (state) {
    // 移除cookie
    Cookies.remove('studentUserName')
    Cookies.remove('studentUserInfo')
    Cookies.remove('studentImagePath')
  }
}

export default {
  namespaced: true,
  state,
  mutations,
  actions
}

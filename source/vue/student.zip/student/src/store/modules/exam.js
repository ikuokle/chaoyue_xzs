import subjectApi from '@/api/subject'

const state = {
  subjects: [] // 科目数据缓存
}

const getters = {
  subjectEnumFormat: (state) => (key) => {
    for (let item of state.subjects) {
      if (item.id === key) {
        return item.name + ' ( ' + item.levelName + ' )'
      }
    }
    return null
  }
}

// 异步操作
const actions = {
  initSubject ({ commit }) {
    subjectApi.list().then(re => {
      commit('setSubjects', re.response)
    })
  }
}

// 状态变更
const mutations = {
  setSubjects: (state, subjects) => {
    state.subjects = subjects
  }
}

export default {
  namespaced: true,
  state,
  getters,
  actions,
  mutations
}

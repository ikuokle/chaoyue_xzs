import { post } from '@/utils/request'

/**
 * 学生主页，获取数据和任务
 */

export default {
  index: () => post('/api/student/dashboard/index'),
  task: () => post('/api/student/dashboard/task')
}

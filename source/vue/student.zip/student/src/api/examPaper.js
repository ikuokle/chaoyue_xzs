import { post } from '@/utils/request'

/**
 * 获取试卷，通过试卷编号查找和试卷列表
 */

export default {
  select: id => post('/api/student/exam/paper/select/' + id),
  pageList: query => post('/api/student/exam/paper/pageList', query)
}

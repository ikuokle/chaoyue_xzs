import { post, postWithLoadTip } from '@/utils/request'

/**
 * 用户登录
 */

export default {
  login: query => postWithLoadTip(`/api/user/login`, query),
  logout: query => post(`/api/user/logout`, query)
}

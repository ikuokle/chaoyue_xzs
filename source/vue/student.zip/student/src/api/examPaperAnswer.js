import { post } from '@/utils/request'

/**
 * 试卷提交记录：提交列表，提交试卷，通过ID查询试卷，查看已提交试卷
 */

export default {
  pageList: query => post('/api/student/exampaper/answer/pageList', query),
  answerSubmit: form => post('/api/student/exampaper/answer/answerSubmit', form),
  read: id => post('/api/student/exampaper/answer/read/' + id),
  edit: form => post('/api/student/exampaper/answer/edit', form)
}

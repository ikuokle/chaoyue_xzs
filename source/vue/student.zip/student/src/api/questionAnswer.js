import { post } from '@/utils/request'

/**
 * 试卷中题目作答：题目作答列表，通过题目ID查看题目
 */

export default {
  pageList: query => post('/api/student/question/answer/page', query),
  select: id => post('/api/student/question/answer/select/' + id)
}

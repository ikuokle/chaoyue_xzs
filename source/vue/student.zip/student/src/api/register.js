import { postWithLoadTip } from '@/utils/request'

export default {
  /**
   *用户注册
   */

  register: query => postWithLoadTip(`/api/student/user/register`, query)
}

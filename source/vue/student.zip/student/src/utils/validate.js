/**
 * 数据验证，对用户提交的表格进行验证
 * @param {string} path
 * @returns {Boolean}
 */
// 验证外部链接
export function isExternal (path) {
  return /^(https?:|mailto:|tel:)/.test(path)
}

// 验证用户名
export function validUsername (str) {
  // eslint-disable-next-line camelcase
  const valid_map = ['admin', 'editor']
  return valid_map.indexOf(str.trim()) >= 0
}

// URL格式验证
export function validURL (url) {
  const reg = /^(https?|ftp):\/\/([a-zA-Z0-9.-]+(:[a-zA-Z0-9.&%$-]+)*@)*((25[0-5]|2[0-4][0-9]|1[0-9]{2}|[1-9][0-9]?)(\.(25[0-5]|2[0-4][0-9]|1[0-9]{2}|[1-9]?[0-9])){3}|([a-zA-Z0-9-]+\.)*[a-zA-Z0-9-]+\.(com|edu|gov|int|mil|net|org|biz|arpa|info|name|pro|aero|coop|museum|[a-zA-Z]{2}))(:[0-9]+)*(\/($|[a-zA-Z0-9.,?'\\+&%$#=~_-]+))*$/
  return reg.test(url)
}

// 大小写验证
export function validLowerCase (str) {
  const reg = /^[a-z]+$/
  return reg.test(str)
}

export function validUpperCase (str) {
  const reg = /^[A-Z]+$/
  return reg.test(str)
}

export function validAlphabets (str) {
  const reg = /^[A-Za-z]+$/
  return reg.test(str)
}

// 类型检查
export function isString (str) {
  if (typeof str === 'string' || str instanceof String) {
    return true
  }
  return false
}

// 数组检查
export function isArray (arg) {
  if (typeof Array.isArray === 'undefined') {
    return Object.prototype.toString.call(arg) === '[object Array]'
  }
  return Array.isArray(arg)
}
